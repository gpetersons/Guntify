package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.SongsModel

/** Radio recommendations always retain the original seed; resuming only changes the first track. */
object RadioQueuePolicy {
    fun seeds(originalSeed: String?, queue: List<SongsModel>): List<String> =
        originalSeed?.takeIf { it.isNotBlank() }?.let { listOf(it) }
            ?: queue.takeLast(5).map { it.spotifyTrackId }.filter { it.isNotBlank() }.distinct()

    fun shuffled(queue: List<SongsModel>): List<SongsModel> {
        if (queue.size < 2) return queue
        val first = queue.drop(1).random()
        return listOf(first) + queue.filter { it != first }.shuffled()
    }

    private fun key(song: SongsModel) = song.spotifyTrackId.ifBlank { "local:${song.id}" }
    fun resumed(seed: SongsModel?, last: SongsModel?, suggestions: List<SongsModel>, rotation: Int = 0): List<SongsModel> {
        val first = last ?: seed
        val candidates = suggestions.filter { key(it) != first?.let(::key) && key(it) != seed?.let(::key) }.distinctBy(::key)
        val offset = if (candidates.isEmpty()) 0 else Math.floorMod(rotation, candidates.size)
        return (listOfNotNull(first) + candidates.drop(offset) + candidates.take(offset)).distinctBy(::key).take(11)
    }
    /** Prefer unused Spotify candidates; a refresh never replaces/restarts the current track. */
    fun refreshed(current: SongsModel, previous: List<SongsModel>, suggestions: List<SongsModel>): List<SongsModel> {
        val candidates = suggestions.filter { key(it) != key(current) }.distinctBy(::key)
        if (candidates.isEmpty()) return emptyList()
        val oldKeys = previous.map(::key).toSet()
        var next = (candidates.filter { key(it) !in oldKeys }.shuffled() + candidates.filter { key(it) in oldKeys }.shuffled()).take(10)
        val oldNext = previous.dropWhile { key(it) != key(current) }.drop(1).take(10)
        if (next.size > 1 && next.map(::key) == oldNext.map(::key)) next = next.drop(1) + next.first()
        return listOf(current) + next
    }

}
