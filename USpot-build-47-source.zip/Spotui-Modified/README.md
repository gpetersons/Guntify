# USpot

USpot is rare621’s modified version of Spotui for Android, built with Jetpack Compose.

Original app credit: [Spotui creators and contributors](https://github.com/Spotui/Spotui). USpot is a modified fork released under **GNU GPL version 3**. See [LICENSE](LICENSE), [NOTICE](NOTICE) and [SOURCE.md](SOURCE.md) for the license, dated changes, credits and source/build information. See MODIFIED_VERIFICATION.md for testing limitations and update-signing requirements.

It connects to your real Spotify account and mirrors the Spotify experience:

- 🎵 **Playlists** — browse, play, add/remove tracks, create new playlists, all synced with your Spotify account
- 📝 **Lyrics** — Spotify's own synced lyrics, with a live preview on the player and a full-screen view
- 📻 **Spotify recommendations** — USpot Radio continues with recommendations from the existing Spotify integration; ordinary collections loop, with optional Smart Shuffle additions
- ❤️ Liked songs, followed artists, listening history and downloads (including lossless FLAC)

## Screenshot

<img src="assets/screenshot-player.png" width="360" alt="Now playing screen"/>

## Credits

spotui builds on the work of several open-source projects:

- [Meld](https://github.com/) — Spotify metadata + YouTube streaming layer
- [Neptune](https://github.com/navneet851/spotify-clone-jetpack-compose) — the original Jetpack Compose Spotify clone this app started from
- [SpotiFLAC](https://github.com/spotbye/SpotiFLAC) — lossless (FLAC) track resolving
- [SimpMusic](https://github.com/maxrave-dev/SimpMusic) — crossfade / DJ-style audio filter processing

## Disclaimer

This project is for educational purposes only. Spotify is a trademark of Spotify AB.

## Sharing an APK

Distribute the matching source ZIP with every APK, keep all notices and license files, and provide a clear source link on the download page. The GitHub workflow packages APK, source, LICENSE, NOTICE and SOURCE.md together. Preserve these files when publishing a release; do not rely solely on expiring Actions artifacts.

## USpot build 42

Adds a configurable top-song Smart Downloads set (20 by default), a local Stats tab, existing-playlist/album discoveries for Made For, popularity-based relevant Radio seeds, queue Undo, Radio tuning/exclusions and diamond Smart Shuffle. Smart Shuffle changes the session queue, not the saved Spotify playlist. USpot Radio is a continuous generated queue; Spotify Radio collections retain their playlist behavior.

Smart Downloads updates while the process is available and resumes on launch. Manual downloads are protected; old automatic files remain until replacements are ready. See the matching build notes for validation and account/device testing limits.

## USpot build 43

Restores the last successful personalized Home cards immediately on reopening, then refreshes in the background. Snapshots are scoped to the signed-in session and listening window; logging out clears them. Failed catalog requests retain the previous successful shelf. New users keep Spotify fallback content. Full-player Smart Shuffle has a separate diamond badge, and Radio tuning controls have transparent press feedback. Build 42 features remain included. Full Android compilation and phone checks remain required.

## USpot build 44

Smart Downloads is off by default. Enable it explicitly in Settings. Existing saved choices and downloaded files are preserved. Includes all build-43 changes.

## USpot build 45

Stats now matches Following: cover collage, top-song feature card, transparent controls, Week/Month/All-time filters, play/time/artist totals, last-seven-day activity, playable ranked tracks and artist cards. The selected song starts through the existing player with the displayed top songs queued; song menus and source-scoped playing indicators are included. Rankings use actual qualified local play counts rather than recommendation weighting. Smart Downloads remains off by default and all build-44 features are retained. APK/device validation remains required.

## USpot build 46

Includes the playable Stats redesign and all earlier changes. Recommended playlists replaces Recommended Stations: real Spotify catalog playlists are found from locally weighted songs/artists and their sampled tracks are checked for relevance. Generated USpot Radios remain in Popular radio. Home starts with Spotify data for a new user and gradually increases local influence, following the chosen target percentage. Hidden discoveries backfill before the card limit, collections are deduplicated across the three main shelves, cache refreshes respect settings/account changes, and authenticated mutation retries are time-bounded. Smart Downloads stays off by default. See build notes for validation and remaining device tests.

Local Stats/Following playback queues are not exposed as dead Spotify playlist shortcuts in Home history; real playlists, pinned Liked/Downloaded collections and listening statistics are retained.

## USpot build 47

Fixes a legacy test that assumed Made For was the only returned Home shelf. The test now selects Made For by title and verifies the separate Recommended playlists fallback. Build 46 successfully assembled the Android APK in GitHub Actions; artifact packaging was blocked by this one failing test (180 of 181 tests passed). Build 47 keeps the same application feature code and retains unit-test gating in the workflow. Device testing remains outstanding.
