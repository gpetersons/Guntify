package com.music.spotui.data.recommendation

import com.music.spotui.audio.StreamRecoveryPolicy
import org.junit.Assert.*
import org.junit.Test

class StreamRecoveryTest {
    @Test fun staleFailuresDoNotSkipTheCurrentSong() {
        assertEquals(StreamRecoveryPolicy.Action.IGNORE, StreamRecoveryPolicy().failure("old", "new"))
    }
    @Test fun retriesCurrentSongBeforeSkippingIt() {
        val policy = StreamRecoveryPolicy()
        assertEquals(StreamRecoveryPolicy.Action.RETRY, policy.failure("A", "A"))
        assertEquals(StreamRecoveryPolicy.Action.SKIP, policy.failure("A", "A"))
    }
    @Test fun repeatedFailuresPauseInsteadOfWrappingForever() {
        val policy = StreamRecoveryPolicy()
        policy.failure("A", "A"); policy.failure("A", "A")
        assertEquals(StreamRecoveryPolicy.Action.RETRY, policy.failure("B", "B"))
        assertEquals(StreamRecoveryPolicy.Action.PAUSE, policy.failure("B", "B"))
    }
    @Test fun audibleRecoveryStartsANewFailureBudget() {
        val policy = StreamRecoveryPolicy()
        policy.failure("A", "A"); policy.failure("A", "A")
        policy.recovered()
        assertEquals(StreamRecoveryPolicy.Action.RETRY, policy.failure("A", "A"))
        assertEquals(StreamRecoveryPolicy.Action.SKIP, policy.failure("A", "A"))
    }
    @Test fun ignoredFailureDoesNotConsumeRetryBudget() {
        val policy = StreamRecoveryPolicy()
        policy.failure("old", "A")
        assertEquals(StreamRecoveryPolicy.Action.RETRY, policy.failure("A", "A"))
    }
}
