package com.music.spotui.audio

/** One fresh lookup per song; pause after two failed songs instead of cycling forever. */
class StreamRecoveryPolicy {
    enum class Action { IGNORE, RETRY, SKIP, PAUSE }
    private val retried = mutableSetOf<String>()
    private var failedSongs = 0
    fun failure(failed: String, current: String): Action {
        if (failed.isBlank() || failed != current) return Action.IGNORE
        if (retried.add(failed)) return Action.RETRY
        failedSongs++
        return if (failedSongs >= 2) Action.PAUSE else Action.SKIP
    }
    fun recovered() { retried.clear(); failedSongs = 0 }
}
