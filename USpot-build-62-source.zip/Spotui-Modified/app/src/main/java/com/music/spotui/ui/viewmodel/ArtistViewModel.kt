package com.music.spotui.ui.viewmodel

import androidx.compose.runtime.State
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.spotui.data.api.Response
import com.music.spotui.data.entity.ArtistOverviewModel
import com.music.spotui.data.entity.ArtistsModel
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.di.CurrentSongState
import com.music.spotui.ui.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ArtistViewModel @Inject constructor(private val repository: AppRepository, private val currentSongState: CurrentSongState) : ViewModel() {

    val currentSongPlayingState: State<Boolean> get() = currentSongState.playingState
    val currentSongId: State<Int> get() = currentSongState.songId


    private val _songs : MutableStateFlow<Response<List<SongsModel>>> = MutableStateFlow(Response.Loading())
    val songs : StateFlow<Response<List<SongsModel>>> = _songs

    private val _artists : MutableStateFlow<Response<List<ArtistsModel>>> = MutableStateFlow(Response.Loading())
    val artists : StateFlow<Response<List<ArtistsModel>>> = _artists

    private val _overview : MutableStateFlow<Response<ArtistOverviewModel>> = MutableStateFlow(Response.Loading())
    val overview : StateFlow<Response<ArtistOverviewModel>> = _overview

    fun updateQueue(songs: List<SongsModel>) { currentSongState.updateQueue(songs); markCollection(songs) }
    val shuffleState get() = currentSongState.shuffle
    fun updateShuffleState(enabled: Boolean) = currentSongState.updateShuffleState(enabled)
    fun startShuffled(songs: List<SongsModel>): SongsModel? { val first = currentSongState.startShuffled(songs); markCollection(songs); return first }

    fun updateSongState(coverUri: String, title: String, singer: String, playingState: Boolean, songId :Int, songIndex : Int = 0, album : String = "") {
        currentSongState.updateSongState(coverUri, title, singer, playingState, songId, songIndex, album)
    }

    val shuffleActive: Boolean get() = shuffleState.value && currentSongState.collection.value?.key == "artist:$loadedArtist"
    private fun markCollection(songs: List<SongsModel>) {
        currentSongState.collection.value = com.music.spotui.data.entity.PlaybackCollection(
            "artist:$loadedArtist", "artist", loadedArtist.orEmpty(), loadedArtist.orEmpty(), songs.firstOrNull()?.coverUri.orEmpty())
    }

    val likeState = currentSongState.likeState

    fun updateLikeState(likeState : Boolean){
        currentSongState.updateLikeState(likeState)
    }

    private var loadedArtist: String? = null

    // Ids of artists the user follows on Spotify, so the Follow button reflects
    // the real account state (not just follows made from this app).
    private val _followedArtistIds: MutableStateFlow<Set<String>> = MutableStateFlow(emptySet())
    val followedArtistIds: StateFlow<Set<String>> = _followedArtistIds

    init {
        fetchArtists()
        viewModelScope.launch(Dispatchers.IO) {
            _followedArtistIds.value = repository.provideFollowedArtists()
                .mapNotNull { it.id.ifBlank { null } }
                .toSet()
        }
    }

    // Loads this artist's top tracks (GraphQL, not rate-limited). Called by the
    // screen with the artist name it was opened for.
    fun loadArtistSongs(artistName: String) {
        if (loadedArtist == artistName) return
        loadedArtist = artistName
        viewModelScope.launch(Dispatchers.IO) {
            repository.provideArtistSongs(artistName).collect { songs ->
                _songs.value = songs as Response<List<SongsModel>>
            }
        }
    }

    private var loadedOverview: String? = null

    // Loads the full Spotify-style artist page (header, monthly listeners, bio,
    // popular tracks, discography, related artists) in one GQL round-trip.
    // Passing the exact Spotify artist id avoids the fuzzy name search.
    fun loadArtistOverview(artistName: String, artistId: String = "") {
        val key = artistId.ifBlank { artistName }
        if (loadedOverview == key) return
        loadedOverview = key
        viewModelScope.launch(Dispatchers.IO) {
            repository.provideArtistOverview(artistName, artistId).collect { overview ->
                _overview.value = overview
                // Keep the legacy songs flow in sync (popular tracks) so any
                // other consumer and the play/queue helpers still work.
                if (overview is Response.Success) {
                    _songs.value = Response.Success(overview.data.topTracks.map { it.song })
                }
            }
        }
    }

    private fun fetchArtists() = viewModelScope.launch(Dispatchers.IO) {
        repository.provideArtists().collect{ artists ->
            _artists.value = artists as Response<List<ArtistsModel>>
        }
    }
}