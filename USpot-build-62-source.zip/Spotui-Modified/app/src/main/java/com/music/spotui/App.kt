package com.music.spotui

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.music.spotui.ui.navigation.MainBottomNavigation
import com.music.spotui.ui.navigation.MyNavHost
import com.music.spotui.ui.navigation.Routes


@RequiresApi(Build.VERSION_CODES.S)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun App() {
    val bottomBarState = rememberSaveable { (mutableStateOf(true)) }
    val bottomBarPlayerState = rememberSaveable { (mutableStateOf(true)) }
    val overlayHeight = androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val overlayInset = with(androidx.compose.ui.platform.LocalDensity.current) { overlayHeight.intValue.toDp() }
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()

    // Control TopBar and BottomBar
    when (navBackStackEntry?.destination?.route) {
        Routes.Home.route -> {
            bottomBarState.value = true
        }
        Routes.Search.route -> {
            bottomBarState.value = true
        }
        Routes.Library.route -> {
            bottomBarState.value = true
        }
        Routes.Album.route -> {
            bottomBarState.value = false
        }
    }

    Scaffold(
        modifier = Modifier,
        bottomBar = {
            MainBottomNavigation(navController = navController, bottomBarState = bottomBarState, bottomBarPlayerState, onHeightChanged = { if (overlayHeight.intValue != it) overlayHeight.intValue = it })
        }
    ) {
        androidx.compose.runtime.CompositionLocalProvider(com.music.spotui.ui.navigation.LocalBottomOverlayInset provides (if (bottomBarState.value) overlayInset else androidx.compose.ui.unit.Dp(0f))) {
            MyNavHost(navHostController = navController, bottomBarState = bottomBarState, bottomBarPlayerState)
        }
    }
}


