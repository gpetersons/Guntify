package com.music.spotui.data.entity

/** Combined Spotify search results: tracks, albums, artists, podcasts + episodes. */
data class SearchResults(
    val songs: List<SongsModel> = emptyList(),
    val albums: List<AlbumsModel> = emptyList(),
    val artists: List<ArtistsModel> = emptyList(),
    val shows: List<PodcastModel> = emptyList(),
    val episodes: List<SongsModel> = emptyList(),
    val playlists: List<LibraryEntry> = emptyList(),
    val nextOffset: Int? = null,
)
