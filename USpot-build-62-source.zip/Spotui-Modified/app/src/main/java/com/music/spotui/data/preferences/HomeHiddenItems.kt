package com.music.spotui.data.preferences

import android.content.Context
import com.music.spotui.data.entity.HomeItem

/** Home-only exclusions. No Spotify mutations or removal of radio seed/progress. */
object HomeHiddenItems {
    fun key(item: HomeItem): String = when (item) {
        is HomeItem.Playlist -> "playlist:" + item.id
        is HomeItem.Album -> "album:" + item.name + "|" + item.artists
        is HomeItem.Radio -> "radio:" + item.seed.spotifyTrackId.ifBlank { item.seed.id.toString() }
        is HomeItem.RecentTrack -> "track:" + item.song.id
        is HomeItem.Artist -> "artist:" + item.id
    }
    private fun prefs(context: Context) = context.getSharedPreferences("home_hidden_items", 0)
    fun hidden(context: Context, item: HomeItem) = key(item) in prefs(context).getStringSet("keys", emptySet()).orEmpty()
    fun hide(context: Context, item: HomeItem) {
        val keys = prefs(context).getStringSet("keys", emptySet()).orEmpty().toMutableSet()
        keys.add(key(item))
        prefs(context).edit().putStringSet("keys", keys).apply()
    }
}
