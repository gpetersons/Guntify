# USpot 1.1 — backup/import and build corrections

Display version remains 1.1; internal Android versionCode advances to 23. Application ID, icon, data directories, and the permanent signing-key setup are unchanged.

## Uploaded build log

The provided Actions run successfully passed the signing-key restore step. It then failed at app:compileDebugKotlin because HomeScreen.kt did not import mutableStateOf. The missing import is corrected.

The log also contained repeated D8 warnings about Kotlin metadata compatibility. This source updates Android Gradle Plugin from 8.4.2 to 8.10.1 and the Gradle wrapper from 8.6 to 8.11.1, retaining Kotlin 2.2.0. The matching workflow explicitly installs Build Tools 35.0.0 and the Android 34 platform. Official compatibility references:
https://developer.android.com/build/kotlin-support
https://developer.android.com/build/releases/agp-8-10-0-release-notes

## New Settings → Data & backup

- Export backup opens Android's Save file picker and writes a USpot backup ZIP outside the app, wherever the user chooses.
- Import backup opens Android's file picker, asks before replacing backed-up local data, pauses playback, and restores the selected archive.
- The backup includes local listening history, likes, saved library/cache data, Home personalization/history/removals, Radio seeds and resume progress, queue/playback position, EQ/appearance/settings, alternative stream choices, and playlist cover files.
- Include downloaded audio is enabled by default and can be disabled for a smaller archive. Download index entries are restored only when their referenced audio files actually exist.
- External local-music file references are retained, but Android file/folder permissions must be granted again after reinstalling or switching devices. The external audio itself is not copied into this backup.
- Passwords, login cookies, access/session tokens, Soulseek usernames, Spotify/SpotiFLAC authentication stores, and private signing keys are excluded. Existing login credentials in the destination installation are preserved. Restore does not submit changes to Spotify.
- Archives use a versioned manifest, explicit file list, byte lengths, and SHA-256 checksums. They are extracted into staging first with path, metadata-size, entry-count, and available-space checks. Validation finishes before live data is replaced. Ordinary restore errors attempt to roll back changed preferences and files.
- Import reloads runtime download/EQ/appearance/playback state and refreshes Settings/Home. Playback stays paused after restore.
- Current downloads must finish before export, preventing active download files from being backed up mid-write.

This feature cannot recover private data from the currently installed old-signed app that has no export button. It protects future installations once this version is installed and a backup is successfully exported. Do not uninstall the old app under the assumption that this new code has already backed it up.

Keep backups private: they contain personal listening history and settings, although account credentials are excluded. Keep the ZIP outside the app so uninstalling does not remove it. Export a backup before restoring another archive if you need to preserve the current local data.

## Validation

- 34 JVM tests passed: all previous policy tests plus backup audio/metadata round-trip, hashes, unsafe-path rejection, extraction quota, malformed archive rejection, and authentication exclusions.
- Four additional codec tests passed against production backup code, covering exact integer/long values, Boolean/Float/String settings, string sets, and rejected unknown types. Total: 38 passing tests.
- All 232 Kotlin source files passed syntax parsing.
- The production backup backend compiled in isolation against Android API classes and org.json; this is not a full Android app build or device test.
- Full Android assembleDebug was attempted using the updated wrapper, but the local environment could not reach the Gradle distribution URL. No new APK was produced here.
- SAF file-picker behavior, permissions, rollback on Android storage failures, runtime refresh, UI, authenticated Spotify features, and install/update behavior still require a successful Actions build and device testing. No claim is made that backup/restore has passed an Android device test.
- Original icon assets remain byte-identical. The complete source ZIP passed integrity checks and includes all preceding USpot modifications.

## Upload/build from your phone

1. Upload USpot-1.1-backup-source.zip unchanged to:
https://github.com/rare621/Spotui/upload/main
2. Replace the existing workflow contents with build-uspot-backup.yml:
https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Keep the EXISTING USPOT_SIGNING_KEYSTORE_BASE64 secret and permanent keystore. Do not generate another key.
4. Run:
https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
5. After both build and tests succeed, download USpot-1.1-APK from Artifacts.

## Phone verification

Export to Downloads with audio, then confirm that the ZIP exists and has a sensible size. Import into a test/fresh installation and compare history, likes, Radio sessions, settings/EQ, covers, and downloaded playback. Check exports without audio, canceled pickers, an unrelated ZIP, corrupted files, insufficient storage, and restoring while music had been playing. After establishing the permanent-key installation, future APKs must install as updates without uninstalling; verify data is still present after one such update.
