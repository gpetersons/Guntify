package com.music.spotui.ui.viewmodel

import androidx.compose.runtime.State
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.spotui.data.api.Response
import com.music.spotui.data.entity.AlbumsModel
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.di.CurrentSongState
import com.music.spotui.ui.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class AlbumViewModel @Inject constructor(private val repository: AppRepository, private val currentSongState: CurrentSongState) :  ViewModel() {

    val currentSongPlayingState: State<Boolean> get() = currentSongState.playingState

    val currentSongId: State<Int> get() = currentSongState.songId

    private val _songs : MutableStateFlow<Response<List<SongsModel>>> = MutableStateFlow(Response.Loading())
    val songs : StateFlow<Response<List<SongsModel>>> = _songs

    private val _albums : MutableStateFlow<Response<List<AlbumsModel>>> = MutableStateFlow(Response.Loading())
    val albums : StateFlow<Response<List<AlbumsModel>>> = _albums

    val queue: State<List<SongsModel>> get() = currentSongState.queue

    fun updateQueue(songs: List<SongsModel>) { currentSongState.updateQueue(songs); markCollection(songs) }

    val shuffleState get() = currentSongState.shuffle
    fun updateShuffleState(enabled: Boolean) = currentSongState.updateShuffleState(enabled)

    fun startShuffled(songs: List<SongsModel>): SongsModel? { val first = currentSongState.startShuffled(songs); markCollection(songs); return first }

    /** Pause/resume global playback (the header play button stays visible while playing). */
    fun setPlaying(playing: Boolean) {
        if (playing) com.music.spotui.di.SongPlayer.play() else com.music.spotui.di.SongPlayer.pause()
        currentSongState.updatePlayingState(playing)
    }

    fun updateSongState(coverUri: String, title: String, singer: String, playingState: Boolean, songId: Int, songIndex : Int = 0, album : String = "") {
        currentSongState.updateSongState(coverUri, title, singer, playingState, songId, songIndex, album)
    }

    val collectionActive: Boolean get() = com.music.spotui.audio.CollectionPlaybackPolicy.active("album:$albumKey", currentSongState.collection.value?.key, currentSongId.value, currentSongState.queue.value.map { it.id })
    val shuffleActive: Boolean get() = shuffleState.value && currentSongState.collection.value?.key == "album:$albumKey" && (_songs.value as? Response.Success)?.data?.any { it.id == currentSongId.value } == true
    private fun markCollection(songs: List<SongsModel>) {
        val id = albumKey ?: return
        val name = id.substringBefore('|')
        val artist = id.substringAfter('|').ifBlank { songs.firstOrNull()?.singer.orEmpty() }
        currentSongState.collection.value = com.music.spotui.data.entity.PlaybackCollection(
            "album:$id", "album", "$name|$artist", name, songs.firstOrNull()?.coverUri.orEmpty(), artist)
    }

    val likeState = currentSongState.likeState

    fun updateLikeState(likeState : Boolean){
        currentSongState.updateLikeState(likeState)
    }
    init {
        fetchAlbums()
    }

    private var albumKey: String? = null

    /** Loads the tracks for a specific album (resolved via Spotify search). */
    fun loadAlbumSongs(name: String, artist: String = "") {
        val key = "$name|$artist"
        if (albumKey == key) return
        albumKey = key
        viewModelScope.launch(Dispatchers.IO) {
            repository.provideAlbumSongs(name, artist).collect { songs ->
                _songs.value = songs as Response<List<SongsModel>>
            }
        }
    }

    private fun fetchAlbums() = viewModelScope.launch(Dispatchers.IO) {
        repository.provideAlbums().collect{ album ->
            _albums.value = album as Response<List<AlbumsModel>>
        }
    }


}
