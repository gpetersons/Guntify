package com.music.spotui.data.api

import android.content.Context
import com.metrolist.spotify.Spotify

/** Retry once only after a definite expired-token rejection. Never fake a successful remote change. */
object SpotifyMutations {
    suspend fun <T> run(context: Context, action: suspend () -> Result<T>): Result<T> {
        if (!SpotifyTokenProvider.ensureToken(context)) return Result.failure(Spotify.SpotifyException(401, "Sign in to Spotify again"))
        val result = kotlinx.coroutines.withTimeoutOrNull(20_000L) { action() }
            ?: return Result.failure(IllegalStateException("Spotify response timed out; check your library before retrying"))
        if ((result.exceptionOrNull() as? Spotify.SpotifyException)?.statusCode == 401 && SpotifyTokenProvider.ensureToken(context, force = true)) return action()
        return result
    }
    fun describe(error: Throwable?): String {
        if (error?.message?.contains("timed out", ignoreCase = true) == true) return "Spotify did not respond in time. Check your library before retrying: the change may already have been applied."
        return when ((error as? Spotify.SpotifyException)?.statusCode) {
        401 -> "Spotify sign-in expired. Sign out and sign in again, then retry."
        403 -> "Spotify did not authorize this change (HTTP 403). This account's sign-in token may not have playlist/library write permission. You can complete the change in Spotify."
        429 -> "Spotify is rate limiting requests (HTTP 429). Wait a little and retry."
        400, 404, 405, 412 -> "Spotify rejected this request (HTTP ${(error as Spotify.SpotifyException).statusCode}). Open Spotify to complete the change."
        else -> "Could not reach Spotify or complete the change. Check your connection and retry."
        }
    }
}
