package com.music.spotui.data.preferences

/** Maturity uses qualifying local listens (>10 seconds) within the user's selected history window. */
object HomeMixPolicy {
    fun localFraction(plays: Int): Double = when {
        plays < 3 -> 0.0
        plays < 20 -> 0.2
        plays < 60 -> 0.4
        plays < 150 -> 0.6
        else -> 0.7
    }
}
