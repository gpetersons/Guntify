package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.preferences.HomeMixPolicy
import org.junit.Assert.*
import org.junit.Test

class RadioQueuePolicyTest {
    private fun song(id: Int, spotify: String = "track$id") = SongsModel(id, "Song $id", "Album", "Artist", "", "", spotify)
    @Test fun continuationKeepsOriginalSeedAfterResume() {
        assertEquals(listOf("original"), RadioQueuePolicy.seeds("original", listOf(song(20), song(21))))
    }
    @Test fun ordinaryAutoplayUsesRecentQueue() {
        assertEquals((6..10).map { "track$it" }, RadioQueuePolicy.seeds(null, (1..10).map(::song)))
    }
    @Test fun resumesLastTrackFirstAndCapsAt15() {
        val result = RadioQueuePolicy.resumed(song(1), song(9), (1..30).map(::song), 3)
        assertEquals(15, result.size)
        assertEquals(9, result.first().id)
        assertFalse(result.any { it.id == 1 })
        assertEquals(15, result.map { it.spotifyTrackId }.distinct().size)
    }
    @Test fun duplicatesUseSpotifyIdentityRatherThanIntegerHash() {
        val result = RadioQueuePolicy.resumed(song(1), song(2), listOf(song(3, "same"), song(4, "same"), song(5)))
        assertEquals(1, result.count { it.spotifyTrackId == "same" })
    }
    @Test fun missingRecommendationsPreserveResumeTrack() {
        assertEquals(listOf(song(9)), RadioQueuePolicy.resumed(song(1), song(9), emptyList()))
    }
    @Test fun newRadioFallsBackToSeed() {
        assertEquals(listOf(song(1)), RadioQueuePolicy.resumed(song(1), null, emptyList()))
    }
    @Test fun missingSeedNeverInventsTracks() {
        assertTrue(RadioQueuePolicy.resumed(null, null, emptyList()).isEmpty())
    }
    @Test fun rotationDoesNotAffectFirstTrack() {
        val result = RadioQueuePolicy.resumed(song(1), song(2), (3..20).map(::song), -1)
        assertEquals(2, result.first().id)
        assertEquals(20, result[1].id)
    }
    @Test fun localMixStagesRetainAtLeast30PercentSpotify() {
        val expected = mapOf(0 to 0.0, 2 to 0.0, 3 to 0.2, 19 to 0.2, 20 to 0.4, 59 to 0.4, 60 to 0.6, 149 to 0.6, 150 to 0.7, 500 to 0.7)
        expected.forEach { (plays, fraction) -> assertEquals(fraction, HomeMixPolicy.localFraction(plays), 0.0) }
    }
}
