package com.music.spotui.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.music.spotui.R
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.preferences.RadioSessions
import com.music.spotui.ui.viewmodel.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun RadioScreen(navController: NavController, seedId: String, player: PlayerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val seed = remember(seedId) { RadioSessions.get(context).firstOrNull { it.spotifyTrackId.ifBlank { it.id.toString() } == seedId } }
    var prepared by remember(seedId) { mutableStateOf<List<SongsModel>>(emptyList()) }
    var loading by remember(seedId) { mutableStateOf(true) }
    var askDownload by remember { mutableStateOf(false) }
    val active = player.activeCollection.value?.key == "radio:$seedId"
    val shuffled = active && player.shuffleState.value
    val stationSongs = if (active) player.queue.value else prepared
    LaunchedEffect(seedId) {
        val recommendations = if (seed?.spotifyTrackId.isNullOrBlank()) emptyList() else withContext(Dispatchers.IO) { player.radioRecommendations(seed!!.spotifyTrackId) }
        prepared = com.music.spotui.data.recommendation.RadioQueuePolicy.resumed(seed, RadioSessions.lastTrack(context, seedId), recommendations)
        loading = false
    }
    if (askDownload) com.music.spotui.ui.components.ConfirmDownloadAllDialog(stationSongs.size, { askDownload = false }) {
        com.music.spotui.di.Downloads.downloadAll(stationSongs, context)
    }
    Column(Modifier.fillMaxSize().background(com.music.spotui.ui.theme.AppBackground).statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("‹ Back", color = Color.White, modifier = Modifier.clickable { navController.popBackStack() }.padding(vertical = 12.dp))
        Spacer(Modifier.height(24.dp))
        GlideImage(model = seed?.coverUri.orEmpty(), contentDescription = "Radio artwork", contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp)))
        Text("${seed?.title ?: "Song"} Radio", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
        Text("Songs are chosen by Spotify based on ${seed?.title ?: "this song"}. Radio continues as you listen.", color = Color(0xFFB3B3B3), fontSize = 15.sp, modifier = Modifier.padding(vertical = 16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Icon(painterResource(R.drawable.ic_player_shuffle), contentDescription = "Shuffle radio",
                tint = if (shuffled) Color(0xFF1ED760) else Color.White,
                modifier = Modifier.size(28.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = stationSongs.isNotEmpty()) {
                    if (active) player.updateShuffleState(!shuffled)
                    else seed?.let { player.resumeRadio(it, prepared, context, shuffled = true) }
                })
            Icon(painterResource(R.drawable.ic_download), contentDescription = "Download current radio queue", tint = Color.White,
                modifier = Modifier.size(28.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = stationSongs.isNotEmpty()) { askDownload = true })
            Spacer(Modifier.weight(1f))
            Button(enabled = stationSongs.isNotEmpty(), onClick = {
                if (active) {
                    if (player.currentSongPlayingState.value) { com.music.spotui.di.SongPlayer.pause() } else com.music.spotui.di.SongPlayer.play()
                } else seed?.let { player.resumeRadio(it, prepared, context) }
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1ED760), contentColor = Color.Black)) {
                Text(if (active && player.currentSongPlayingState.value) "Pause" else "Play")
            }
        }
        if (loading) CircularProgressIndicator(Modifier.padding(top = 20.dp), color = Color(0xFF1ED760))
        if (!loading && stationSongs.isEmpty()) Text("Recommendations are unavailable. Try again when connected.", color = Color.LightGray, modifier = Modifier.padding(top = 20.dp))
        Text("Open the queue in the full-screen player to see the songs coming next.", color = Color.Gray, modifier = Modifier.padding(top = 24.dp, bottom = 140.dp))
    }
}
