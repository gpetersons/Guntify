package com.music.spotui.ui.theme

import android.content.Context
import androidx.compose.runtime.mutableStateOf

/** One additive preference; existing settings and storage keys are left intact. */
object AppearanceSettings {
    val trueBlack = mutableStateOf(false)
    private var loaded = false
    fun initialize(context: Context) {
        if (loaded) return
        trueBlack.value = context.getSharedPreferences("settings_prefs", 0).getBoolean("uspot_true_black", false)
        loaded = true
    }
    fun setTrueBlack(context: Context, enabled: Boolean) {
        trueBlack.value = enabled
        context.getSharedPreferences("settings_prefs", 0).edit().putBoolean("uspot_true_black", enabled).apply()
    }
}
