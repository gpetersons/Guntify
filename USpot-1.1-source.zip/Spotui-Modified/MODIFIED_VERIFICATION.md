# USpot 1.1 source handoff

Display name/version: USpot 1.1. Android versionCode: 22. Application ID remains `com.music.spotui.modified`. The original icon and source namespace remain unchanged.

## Included changes

- Settings credits Shawn (rare621) as USpot's creator and links to the original Spotui creators/contributors. The old Spotui version/update pill is removed. About displays the actual USpot build version.
- Appearance → True dark mode persists an additive preference and uses black main backgrounds/surfaces. Artwork gradients, card contrast, dialogs, and controls remain distinguishable.
- Settings/category pages have extra scrolling space measured from the actual mini-player and navigation bar height, including device navigation insets.
- More like rows rotate daily among the top three artists from the last 30 days of local qualified listening. Plays must exceed 10 seconds; Spotify-imported entries and future/older records are excluded. Scores decay over 14 days and receive triple weight in the last seven days. An artist needs three qualified plays on at least two days, preventing one-day testing sprees from immediately relabeling seeded sections.
- Catalog searches resolve the artist by an exact name match. Playlist candidates are sampled against that artist and Spotify's related artists; keyword-only results and weak overlaps are rejected. At least two validated playlists are required before a row changes. Title and playlists change together; if recommendations fail, the original Spotify row remains. Other named/editorial/genre rows remain protected. General Home personalization still retains the original permanent Spotify share.
- Existing history keys, login/settings keys, Radio seeds/resume tracks, downloads index, offline files under filesDir/downloads, and playback snapshots keep their storage names. History capacity increases from 500 to 10,000 without clearing old records. Unmeasured old plays remain visible but are not retroactively qualified.
- Previous Radio, queue menus/animation, Following feed, manual EQ, playlist/library actions, downloads, header colors, and playback restoration changes remain included.
- Update checking now targets rare621/Spotui and only USpot-labeled releases, preventing offers of upstream Spotui versions after the display-version reset.

## Critical update signing requirement

An ordinary Android update preserves app data when its application ID and signing certificate match the installed app and its internal version code is sufficiently high. Renaming the label and resetting the displayed version to 1.1 do not change storage identity; versionCode advances to 22.

The previous GitHub workflow used the runner's default debug signing key. On ephemeral runners that can mean a different certificate each build. No signing keystore was present in the supplied source/repository checkout. A matching private signing key cannot be recovered from the APK alone.

This package's workflow REQUIRES the existing signing keystore as a GitHub Actions secret named `USPOT_SIGNING_KEYSTORE_BASE64`. It deliberately stops if missing rather than generating an incompatible update. The base64 value must encode the ORIGINAL private keystore, not the APK or signing certificate. Keep that same secret for future updates.

For a standard Android debug keystore, alias/password defaults are androiddebugkey/android. For a custom key, also configure `USPOT_STORE_PASSWORD`, `USPOT_KEY_ALIAS`, and `USPOT_KEY_PASSWORD` as Actions secrets. Do not upload a private keystore or its base64 text to the public repository root/source ZIP.

Until the installed build's key is recovered, a compatible update and preservation of current installed data cannot be guaranteed. Do not uninstall the current app to work around a signing mismatch: Android uninstall deletes private app data. No keystore was generated or replaced in this task.

Official update rules: https://developer.android.com/google/play/app-updates

## Validation and limitations

- 28 pure JVM policy tests passed against production code, including top-three weighting/qualification, safe playlist validation, rotating title-content pairs, unchanged seeded rows on failure, and previous Radio/clock/following policies.
- All 226 Kotlin files passed syntax parsing. This is not a complete Android compilation/type check.
- Android assembleDebug was attempted and failed before Kotlin compilation because com.android.application 8.4.2 could not be resolved in this environment. No APK was produced here.
- Android device layout, persisted true-black toggling, settings scrolling, live Spotify catalogs/mutations, playback, and signed update installation have not been tested here.
- Original icon assets were compared byte-for-byte. The complete source ZIP passed archive integrity verification.

## Phone build steps

1. Upload `USpot-1.1-source.zip` unchanged to https://github.com/rare621/Spotui/upload/main
2. Replace the contents of the existing workflow with `build-uspot.yml` at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Configure the ORIGINAL saved signing key under repository Settings → Secrets and variables → Actions. This is required before the build can produce an update APK.
4. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
5. After successful build/tests, download USpot-1.1-APK from the run's artifacts. Install as an update without uninstalling the existing app.

## Device checks after a successful compatible build

Verify previous settings/login/history/downloads/Radio sessions remain; label/version/credits are correct; true dark mode persists after reopening; bottom Settings controls can scroll above the mini-player; and More like titles/contents change together only after qualification and successful playlist validation. Recheck queue menus, Followed feed, Radio continuity, manual EQ, and playback close/reopen behavior.
