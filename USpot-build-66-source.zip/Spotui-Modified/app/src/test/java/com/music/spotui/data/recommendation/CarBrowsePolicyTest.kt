package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.*
import com.music.spotui.ui.notification.CarBrowsePolicy
import org.junit.Assert.*
import org.junit.Test

class CarBrowsePolicyTest {
    private fun song(id: Int) = SongsModel(id, "Song $id", "Album", "Artist", "art", "q$id", "s$id")
    @Test fun recentIsFirstAndRootFitsFourBrowsableTabs() {
        val root = CarBrowsePolicy.root()
        assertEquals(listOf("Recent", "Liked Songs", "Downloads", "Library"), root.map { it.title })
        assertTrue(root.all { !it.playable })
    }
    @Test fun radioRowIsPlayableWithOriginalStationIdentity() {
        val seed = song(1)
        val row = CarBrowsePolicy.recent(listOf(HomeItem.Radio(seed))).single()
        assertTrue(row.playable)
        assertEquals("s1", CarBrowsePolicy.radioStation(row.id))
        assertEquals("Song 1 Radio", row.title)
    }
    @Test fun mixedRadioKeepsItsOwnNameAndSyntheticId() {
        val seed = song(1).copy(title = "My mix", spotifyTrackId = "uspot-mix:one")
        val row = CarBrowsePolicy.recent(listOf(HomeItem.Radio(seed))).single()
        assertEquals("My mix", row.title)
        assertEquals(seed.spotifyTrackId, CarBrowsePolicy.radioStation(row.id))
    }
    @Test fun localRadioWithoutSpotifyIdStillHasStableIdentity() {
        val seed = song(42).copy(spotifyTrackId = "")
        assertEquals("42", CarBrowsePolicy.radioStation(CarBrowsePolicy.recent(listOf(HomeItem.Radio(seed))).single().id))
    }
    @Test fun radioIdsRoundTripSpecialCharacters() {
        val station = "mix:a/b + é%"
        assertEquals(station, CarBrowsePolicy.radioStation(CarBrowsePolicy.radioId(station)))
        assertNull(CarBrowsePolicy.radioStation("playlist/s1"))
        assertNull(CarBrowsePolicy.radioStation("radio/%broken"))
    }
    @Test fun recentsExcludeSongsArtistsAndDuplicateCollections() {
        val radio = HomeItem.Radio(song(1))
        val rows = CarBrowsePolicy.recent(listOf(HomeItem.RecentTrack(song(2)), HomeItem.Artist("Artist", "art", "a"), radio, radio))
        assertEquals(1, rows.size)
    }
    @Test fun collectionOrderIsPreservedAndBounded() {
        val rows = CarBrowsePolicy.recent((1..60).map { HomeItem.Radio(song(it)) })
        assertEquals(40, rows.size)
        assertEquals("s1", CarBrowsePolicy.radioStation(rows.first().id))
        assertTrue(CarBrowsePolicy.recent(listOf(HomeItem.Radio(song(1))), -1).isEmpty())
    }
    @Test fun likedAndDownloadsUseTheirExistingBrowseNodes() {
        val rows = CarBrowsePolicy.recent(listOf(HomeItem.Playlist("Liked", "art", "", "liked-songs"), HomeItem.Playlist("Offline", "art", "", "downloaded-offline")))
        assertEquals(listOf("liked", "downloads"), rows.map { it.id })
        assertTrue(rows.none { it.playable })
    }
    @Test fun albumNamesAndArtistsCannotBreakBrowsePath() {
        val row = CarBrowsePolicy.recent(listOf(HomeItem.Album("A/B", "art", "Artist", "C/D"))).single()
        assertEquals("album/A%2FB/C%2FD", row.id)
    }
    @Test fun sameSongInTwoCollectionsHasDifferentPlaybackIds() {
        assertNotEquals(CarBrowsePolicy.trackId("playlist/a", song(1)), CarBrowsePolicy.trackId("playlist/b", song(1)))
    }
    @Test fun savedRadioQueueWinsOverSeedAndOtherResumeTrack() {
        val saved = (3..20).map(::song)
        assertEquals(saved.take(11), CarBrowsePolicy.radioSongs(song(1), song(2), listOf(song(1)), saved))
    }
    @Test fun missingQueueStartsFromLastTrackThenOriginalAnchor() {
        assertEquals(listOf(song(2)), CarBrowsePolicy.radioSongs(song(1), song(2), listOf(song(1)), emptyList()))
        val marker = song(1).copy(url = "", spotifyTrackId = "uspot-mix:a")
        assertEquals(listOf(song(3)), CarBrowsePolicy.radioSongs(marker, null, listOf(song(3)), emptyList()))
        assertTrue(CarBrowsePolicy.radioSongs(marker, null, emptyList(), emptyList()).isEmpty())
    }
}
