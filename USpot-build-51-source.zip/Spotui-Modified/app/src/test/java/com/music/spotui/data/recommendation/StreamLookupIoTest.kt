package com.music.spotui.data.recommendation

import com.music.spotui.audio.BlockingLookupGate
import com.music.spotui.audio.StreamUrlProbe
import java.net.InetSocketAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Test

class StreamLookupIoTest {
    @Test fun stuckLegacyWorkerDoesNotQueueOtherSongs() = runBlocking {
        val gate = BlockingLookupGate()
        val release = CountDownLatch(1)
        val entered = CountDownLatch(1)
        try {
            assertNull(gate.run(100) {
                entered.countDown()
                while (release.count > 0) { try { release.await() } catch (_: InterruptedException) {} }
                "late"
            })
            assertTrue(entered.await(1, TimeUnit.SECONDS))
            assertNull(withTimeout(200) { gate.run(5_000) { fail("Must not queue a second worker") } })
        } finally { release.countDown() }
    }
    @Test fun cancellationInterruptsWorkerAndNextSongCanUseGate() = runBlocking {
        val gate = BlockingLookupGate(); val entered = CountDownLatch(1); val exited = CountDownLatch(1)
        val task = launch { gate.run(5_000) { entered.countDown(); try { CountDownLatch(1).await() } finally { exited.countDown() } } }
        yield(); assertTrue(entered.await(1, TimeUnit.SECONDS)); task.cancelAndJoin()
        assertTrue(exited.await(1, TimeUnit.SECONDS))
        withTimeout(1_000) { while (gate.run(200) { "fresh" } == null) yield() }
    }
    @Test fun legacyExceptionDoesNotPoisonTheGate() = runBlocking {
        val gate = BlockingLookupGate()
        try { gate.run(1_000) { throw IllegalStateException("test") }; fail("Expected failure") }
        catch (_: IllegalStateException) {}
        assertEquals("fresh", gate.run(1_000) { "fresh" })
    }
    @Test fun zeroBudgetDoesNotReserveWorker() = runBlocking {
        val gate = BlockingLookupGate(); assertNull(gate.run(0) { "unused" }); assertEquals("fresh",gate.run(1_000){"fresh"})
    }
    @Test fun cancelledParentDoesNotReturnAFalseMiss() = runBlocking {
        val gate=BlockingLookupGate();var returned=false
        val task=launch { gate.run(5_000) { Thread.sleep(5_000) };returned=true }
        yield();task.cancelAndJoin();assertFalse(returned)
    }

    private suspend fun serverTest(code: Int, mime: String, block: suspend (String) -> Unit) {
        val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        server.createContext("/") { exchange ->
            exchange.responseHeaders.add("Content-Type",mime)
            exchange.sendResponseHeaders(code,20_000)
            exchange.responseBody.use { it.write(ByteArray(20_000)) }
        }
        server.start()
        try { block("http://127.0.0.1:${server.address.port}/") } finally { server.stop(0) }
    }
    private val httpClient = OkHttpClient()
    @org.junit.After fun shutdownNetwork() { httpClient.dispatcher.executorService.shutdownNow(); httpClient.connectionPool.evictAll() }
    private fun call(url:String)=httpClient.newCall(Request.Builder().url(url).build())
    @Test fun acceptsWorkingAudio()=runBlocking { serverTest(206,"audio/webm") { assertTrue(StreamUrlProbe.check(call(it),20_000)) } }
    @Test fun refusesForbiddenAudioInsteadOfPassingItToThePlayer()=runBlocking { serverTest(403,"audio/webm") { assertFalse(StreamUrlProbe.check(call(it),20_000)) } }
    @Test fun refusesHtmlSuccessPage()=runBlocking { serverTest(200,"text/html") { assertFalse(StreamUrlProbe.check(call(it),20_000)) } }
    @Test fun probesBodyWhenLengthIsUnknown()=runBlocking { serverTest(200,"audio/webm") { assertTrue(StreamUrlProbe.check(call(it),null)) } }
    private suspend fun stalledProbe(parentCancellation:Boolean) {
        val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        val release=CountDownLatch(1);val entered=CountDownLatch(1)
        server.createContext("/") { exchange ->
            entered.countDown();release.await(2,TimeUnit.SECONDS)
            runCatching { exchange.close() }
        }
        server.start()
        val request=call("http://127.0.0.1:${server.address.port}/")
        try {
            if(parentCancellation) {
                val returned=AtomicBoolean(false)
                coroutineScope {
                    val task=launch { StreamUrlProbe.check(request,20_000,5_000);returned.set(true) }
                    yield();assertTrue(entered.await(1,TimeUnit.SECONDS));task.cancelAndJoin();assertFalse(returned.get())
                }
            } else assertTrue(withTimeout(1_000) { StreamUrlProbe.check(request,20_000,150) })
            assertTrue(request.isCanceled())
        } finally { release.countDown();server.stop(0) }
    }
    @Test fun probeTimeoutCancelsNetworkCallAndAllowsPlayerAttempt()=runBlocking { stalledProbe(false) }
    @Test fun parentCancellationCancelsNetworkCallWithoutReportingSuccess()=runBlocking { stalledProbe(true) }
}
