# USpot 1.1 — backup/import and build corrections

Display version remains 1.1; internal Android versionCode advances to 23. Application ID, icon, data directories, and the permanent signing-key setup are unchanged.

## Uploaded build log

The provided Actions run successfully passed the signing-key restore step. It then failed at app:compileDebugKotlin because HomeScreen.kt did not import mutableStateOf. The missing import is corrected.

The log also contained repeated D8 warnings about Kotlin metadata compatibility. This source updates Android Gradle Plugin from 8.4.2 to 8.10.1 and the Gradle wrapper from 8.6 to 8.11.1, retaining Kotlin 2.2.0. The matching workflow explicitly installs Build Tools 35.0.0 and the Android 34 platform. Official compatibility references:
https://developer.android.com/build/kotlin-support
https://developer.android.com/build/releases/agp-8-10-0-release-notes

## New Settings → Data & backup

- Export backup opens Android's Save file picker and writes a USpot backup ZIP outside the app, wherever the user chooses.
- Import backup opens Android's file picker, asks before replacing backed-up local data, pauses playback, and restores the selected archive.
- The backup includes local listening history, likes, saved library/cache data, Home personalization/history/removals, Radio seeds and resume progress, queue/playback position, EQ/appearance/settings, alternative stream choices, and playlist cover files.
- Include downloaded audio is enabled by default and can be disabled for a smaller archive. Download index entries are restored only when their referenced audio files actually exist.
- External local-music file references are retained, but Android file/folder permissions must be granted again after reinstalling or switching devices. The external audio itself is not copied into this backup.
- Passwords, login cookies, access/session tokens, Soulseek usernames, Spotify/SpotiFLAC authentication stores, and private signing keys are excluded. Existing login credentials in the destination installation are preserved. Restore does not submit changes to Spotify.
- Archives use a versioned manifest, explicit file list, byte lengths, and SHA-256 checksums. They are extracted into staging first with path, metadata-size, entry-count, and available-space checks. Validation finishes before live data is replaced. Ordinary restore errors attempt to roll back changed preferences and files.
- Import reloads runtime download/EQ/appearance/playback state and refreshes Settings/Home. Playback stays paused after restore.
- Current downloads must finish before export, preventing active download files from being backed up mid-write.

This feature cannot recover private data from the currently installed old-signed app that has no export button. It protects future installations once this version is installed and a backup is successfully exported. Do not uninstall the old app under the assumption that this new code has already backed it up.

Keep backups private: they contain personal listening history and settings, although account credentials are excluded. Keep the ZIP outside the app so uninstalling does not remove it. Export a backup before restoring another archive if you need to preserve the current local data.

## Validation

- 34 JVM tests passed: all previous policy tests plus backup audio/metadata round-trip, hashes, unsafe-path rejection, extraction quota, malformed archive rejection, and authentication exclusions.
- Four additional codec tests passed against production backup code, covering exact integer/long values, Boolean/Float/String settings, string sets, and rejected unknown types. Total: 38 passing tests.
- All 232 Kotlin source files passed syntax parsing.
- The production backup backend compiled in isolation against Android API classes and org.json; this is not a full Android app build or device test.
- Full Android assembleDebug was attempted using the updated wrapper, but the local environment could not reach the Gradle distribution URL. No new APK was produced here.
- SAF file-picker behavior, permissions, rollback on Android storage failures, runtime refresh, UI, authenticated Spotify features, and install/update behavior still require a successful Actions build and device testing. No claim is made that backup/restore has passed an Android device test.
- Original icon assets remain byte-identical. The complete source ZIP passed integrity checks and includes all preceding USpot modifications.

## Upload/build from your phone

1. Upload USpot-1.1-backup-source.zip unchanged to:
https://github.com/rare621/Spotui/upload/main
2. Replace the existing workflow contents with build-uspot-backup.yml:
https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Keep the EXISTING USPOT_SIGNING_KEYSTORE_BASE64 secret and permanent keystore. Do not generate another key.
4. Run:
https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
5. After both build and tests succeed, download USpot-1.1-APK from Artifacts.

## Phone verification

Export to Downloads with audio, then confirm that the ZIP exists and has a sensible size. Import into a test/fresh installation and compare history, likes, Radio sessions, settings/EQ, covers, and downloaded playback. Check exports without audio, canceled pickers, an unrelated ZIP, corrupted files, insufficient storage, and restoring while music had been playing. After establishing the permanent-key installation, future APKs must install as updates without uninstalling; verify data is still present after one such update.


# USpot 1.1 — build 43

Complete cumulative source based on build 42. All 352 previous source files are retained. Added Home snapshot storage and its unit tests; existing playback, Smart Downloads, Stats, queue Undo, Radio tuning, Smart Shuffle, personalization, Library, backup, equalizer, theme and licensing changes are preserved.

Home startup: the last successful Spotify base feed and personalized discovery shelves are saved locally. The ViewModel restores discovery shelves before the first Home render; the base feed is emitted from storage before network requests. The signed-in account's section titles, item ordering, Spotify IDs and playable Radio seeds survive restart. Refreshes happen in the background; an empty failed shelf retains the previous successful shelf. Personalization settings and listening window remain respected. New users retain Spotify fallbacks. One successful load after installing this build is needed to populate the new cache. Existing artwork caching is unchanged; cold image downloads can still take time.

Account changes/logouts clear the snapshots, and the codec checks a one-way session fingerprint and history-window scope. No credentials or listening history are added to network requests. Cache data is expendable and is not added to exported backups; the user's actual listening history and settings remain in the existing backup system. Package ID and signing configuration remain unchanged; versionCode is 43, display version 1.1. Keep the existing signing key and install as an update.

Player: Smart Shuffle diamond is outside the shuffle glyph, positioned as a separate upper-right badge within a 48dp transparent touch target; accessibility descriptions identify off/on/Smart modes.

Radio tuning: Stay close, Balanced and Explore more have no gray ripple/press highlight. Selection remains green with a transparent background.

Validation: seven new production-code JSON/policy tests passed (all Home item types, ordering/title/ID preservation, account/window rejection, malformed/future format, retaining good shelves and successful replacements). Four storage-adapter tests passed (persisted read, account isolation, empty-result protection and logout clearing). Whole-project Kotlin syntax checks and Android resource compilation also passed; the updated discovery method compiled against the actual Spotify models. These are JVM/source checks, not Android phone tests. Full Android compilation was attempted but stopped before configuration because the Gradle wrapper could not reach services.gradle.org (Network is unreachable). UI appearance, actual cold launch, Bluetooth/Android Auto and authenticated Spotify account operations still require APK/device testing. Earlier build-42 focused test results remain documented separately and are not a substitute for this build's APK test.

Upload USpot-build-43-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-43.yml using https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow compiles/tests the Android project and bundles APK, exact source ZIP and license notices. This build has not been uploaded or run on GitHub by the assistant; connector writes were previously rejected with HTTP 403.


# USpot 1.1 — build 44

Smart Downloads now defaults to disabled. Neither launching nor updating the app enables it. The existing explicit Settings choice is preserved, including users who deliberately enabled the feature. Existing downloaded files are not deleted. The default target remains 20 songs if the user enables it.

All build-43 source and features are retained. Package ID and signing configuration are unchanged; internal versionCode is 44. Install as an update using the existing signing key.

Validation: inspected the production preference getter and confirmed its absent-value default is false. No new Android compilation or device test was performed for this one-line behavior change. Build-43 validation results and limitations still apply. The supplied workflow compiles and tests the Android project on GitHub.

Upload USpot-build-44-source.zip unchanged to the repository root. Replace .github/workflows/build-spotui-modified.yml with build-uspot-44.yml and run the workflow. These files have not been uploaded to GitHub by the assistant.


# USpot 1.1 — build 45

Stats redesign: same visual language as Following, with a theme-aware green gradient hero, four-cover collage, top track, Play/Pause and regular/Smart Shuffle controls. Week/Month/All-time filters have transparent press feedback. Compact plays, recorded time and distinct artist cards; a last-seven-calendar-days activity chart; ranked artwork song rows with play counts; horizontal top-artist cards. Local listening data loads and aggregates off the main thread. Bottom padding uses the actual mini-player/navigation inset.

Playback: song rows call the existing PlayerViewModel queue/state operations and SongPlayer.playSong. The selected track starts at its queue index, with up to ten displayed ranked songs available. Play/Pause resumes the active Stats source; Shuffle uses the same player state and source-scoped indicator as collections. Current tracks have the existing glow/animated playing bars. Each song has a correctly scoped three-dot SongOptionsSheet. Artist cards open the existing artist route. Artist images are artwork from listened tracks, not claimed Spotify profile portraits. The source is named Your top songs • week/month/all time; existing non-Radio loop behavior applies.

Stats accuracy: actual play counts, not Home recommendation scores. Only qualified local listening (>10 seconds, not Spotify-imported or future records) counts. Duplicate Spotify IDs group as one song; local songs group by local ID. Artist names merge case variants and count collaborators once per visit. Calendar activity uses the device time zone. Recorded time remains approximate for legacy history, as explained in the UI; retained history may not cover all historical listening.

Cumulative: includes all build-44 files and prior work, including remembered personalized Home, separate full-player Smart Shuffle diamond, transparent Radio tuning and Smart Downloads disabled by default. Saved explicit settings and existing downloaded files remain untouched. Same application ID, display version 1.1 and signing configuration; internal versionCode 45. Install using the same signing key as an update.

Validation: nine new production stats policy tests passed (qualified plays, frequency ranking, Spotify/local grouping, date ranges, collaborators, device calendar, empty state and artwork fallback). The production StatsContent and stats policy compiled with the real Compose 1.6.8 / Material3 1.2.1 / Glide Compose APIs and Compose compiler, using temporary adapters for navigation, injection, player and storage. This is an isolated compile, not a complete APK build or device playback test. Whole-project Kotlin syntax checks and Android resource compilation passed. A complete Gradle build was attempted but failed before configuration while downloading Gradle 8.11.1: Network is unreachable. Audio output, navigation on-device and rendered appearance still require testing the APK. No GitHub upload or run was performed by the assistant.

Build: upload USpot-build-45-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-45.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow runs assembleDebug and unit tests, and packages matching source and GPL notices alongside the APK.


# USpot 1.1 — build 46

This is the complete cumulative update: playable Stats redesign plus Recommended playlists and the bug review. All build-45 files are retained; only one new test file is added. Same package ID, original update signing configuration and display version 1.1; internal versionCode 46.

Stats: Following-style green hero/collage, Week/Month/All-time filters, listening totals, seven-day activity, artwork song rankings and horizontal artist cards. Song taps invoke PlayerViewModel queue/state operations and SongPlayer.playSong; the chosen song starts at the correct queue index. Play/Pause, regular/Smart Shuffle, source-scoped glow/animated bars, per-song three-dot menus and existing artist navigation are wired. Artist imagery uses artwork from listened tracks, not claimed artist portraits. Bottom padding follows the mini-player/navigation inset. Actual frequency ranks songs, not recommendation scores; only qualified local plays count. Recorded time for older history remains incomplete. Incomplete newer history metadata now falls back to an available playback URL from an earlier visit to the same song.

Recommended playlists: replaces Recommended Stations/Recommended radios. Only HomeItem.Playlist objects with nonblank Spotify IDs are admitted; Radio seeds and albums cannot masquerade as playlists. Catalog search uses the most influential local artists derived from qualified listening over the selected window, with recency/frequency weighting and extra emphasis on the last week. Candidate playlist tracks are sampled against those artists and Spotify-related artist IDs using the existing Spotify integration. Links open the existing Spotify playlist screen. This is not a claim to use Spotify's proprietary recommendations algorithm or to list only Spotify-owned editorial playlists. Some legitimate playlists may be unavailable through this account's catalog responses.

New users: 0–2 qualified local plays retain 100% original Spotify content; local influence then rises through 20/40/60/80/100% maturity bands, scaled by the user's target slider. Spotify backfills when relevant local discoveries are insufficient. Generic Made For fallback uses the current signed-in account name, while existing Spotify personalized titles are retained. Available Spotify albums and catalog playlists populate fallback shelves; no fake local listening is synthesized. Stats stays empty until there are actual USpot listens. Local listening logs are not uploaded to Spotify.

Cache and review fixes: preserve the last good Home/discovery snapshots and refresh in the background. Older generated Radio cache rows are ignored by the new playlist shelf; its first catalog discovery must load once, then is cached for later starts. Empty discovery responses retain successful shelves. Hidden candidates are filtered before limiting the displayed cards, allowing backfill; collections are deduplicated across the three main shelves. An in-flight discovery is rejected if its settings/window or account changed. Late responses cannot tag/overwrite another account's snapshot. Spotify mutation retries after a confirmed HTTP 401 token refresh now have the same 20-second timeout as the original attempt; unconfirmed timed-out writes are not blindly retried. Local Stats/Following queues no longer become dead Spotify playlist shortcuts in Home history; previously stored dead mix shortcuts are hidden without deleting other history. Their actual song listens still contribute to Stats and personalization. This does not prove live Spotify create/remove/like operations work for the account.

Smart Downloads remains disabled by default; explicit saved choices and existing files are preserved. Prior Radio queue/history/resume, stream preparation, theme, backup/export, equalizer, navigation and GPL notices are retained. No browser/PC version is introduced.

Validation: 42 production policy/JSON tests passed (Home/Spotify fallback/transition, playlist-only shelf and IDs, deduplication, signed-in fallback naming, Stats and cache format); 15 actual queue/preferences/history/download-coordinator tests passed using platform adapters; nine cache/account-change/history-shortcut adapter tests passed; six Spotify-mutation retry/timeout tests passed using the actual mutation code, real Spotify exception types and a controlled token adapter. Total: 72 focused tests. Isolated StatsContent compilation passed with the real Compose/Material3/Glide APIs and Compose compiler, with adapters for navigation/injection/player/storage. Discovery code compiled against real Spotify model types. These are not Android device or live Spotify account tests. Whole-project Kotlin syntax checks and Android resource compilation passed. Full local APK build remains blocked at downloading Gradle 8.11.1 (Network is unreachable), before Android configuration; no APK/device appearance or audio validation is claimed.

Install/build: use USpot-build-46-source.zip unchanged at the repository root. Replace .github/workflows/build-spotui-modified.yml with build-uspot-46.yml. Run the existing GitHub Actions workflow, which compiles/tests Android and bundles APK, matching source and license notices. Preserve the existing signing key and install as an update. No source upload or GitHub run was performed by the assistant.

Upload: https://github.com/rare621/Spotui/upload/main
Workflow editor: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
Build: https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml


# USpot 1.1 — build 47

The supplied GitHub Actions logs (logs_104796106994.zip) confirm that the exact final build-46 source ZIP was used: SHA256 460733aa0030f6820c882b7340e3571ab01b1a190917d9cb67c3a4df5ff68f35. :app:assembleDebug completed successfully in 4m45s. The subsequent unit-test stage ran 181 tests: 180 passed and one failed. Because tests gate packaging, no downloadable APK artifact was published by that workflow run.

Failure: ListeningFeaturesTest.madeForAcceptsExistingRelevantPlaylistsAlongsideAlbums, line 59. It called single() on the complete Home shelf list. Home now returns Made For plus Recommended playlists, so this assumption threw IllegalArgumentException. The production Home behavior was expected; the older assertion had not been updated.

Fix: select exactly one shelf whose title matches the original Made For account title. Keep the existing content/count assertions and additionally verify that unused Spotify playlists populate Recommended playlists. No application feature logic changed. VersionCode increases to 47; display version 1.1, application ID and signing configuration stay the same. All build-46 features remain included, including playable Stats, personalized Spotify playlist recommendations, Spotify-first onboarding and Smart Downloads off by default.

Validation: the corrected test and affected Home/recommendation/Stats/cache tests run together as 52 focused JVM tests. GitHub must rerun all 181 Android unit tests for build 47; this is not a claim that the complete new workflow or phone playback has already passed. Build-46 Android assembly success is evidenced by the uploaded logs; on-device audio, appearance and authenticated account mutations still need testing.

Upload USpot-build-47-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-47.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . Both assembleDebug and testDebugUnitTest remain enabled and gate APK publication. Keep the existing signing key and install as an update.


# USpot 1.1 — build 48

Home recommendation inputs increase from five to up to 15 distinct Spotify song IDs from qualified local listening. Top artists remains capped at five. Fewer songs are used when the user's qualified history contains fewer than 15 distinct identifiable songs; new users do not need to reach 15 before personalization can begin.

The existing window (30 days by default), frequency/recency weighting and extra last-week weight are unchanged. New users start with original Spotify data; maturity still gradually increases local influence up to the selected slider target, with Spotify content filling discovery shortfalls. Listening logs remain local. The existing playlist-catalog search samples tracks for relevance; it currently queries the top three of the five artist overviews. Made For album inputs and artist matching can use all 15 song metadata results. Catalog metadata requests now run at most four concurrently, preserving deterministic ranking and reducing request bursts. Saved Home cards stay visible during refresh.

Smart Downloads remains off by default, with target 20 if explicitly enabled. Stats song rankings/display count and Radio queue/seed behavior are unchanged. All build-47 files and features, including its corrected unit test, are retained. Same application ID, signing configuration and display version 1.1; versionCode is 48.

Validation: 52 affected Home/recommendation/Stats/cache tests passed, including a dataset larger than both limits that verifies 15 ranked songs, five ranked artists and recent-week priority. The updated discovery code is checked against real Spotify model APIs. Complete build 48 APK compilation and device testing are pending; supplied build-46 logs established successful Android assembly for that older build, not build 48. The workflow keeps both assembleDebug and all app unit tests enabled.

Upload USpot-build-48-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-48.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . Keep the same signing key and install as an update. No files were uploaded or workflow run started on GitHub by the assistant.


# USpot 1.1 — build 49

Home diversity: personalized Made For, Recommended playlists and generated Popular radio candidates are spread across artist groups before selecting repeated entries from one artist. Group selection retains taste order for ties. Albums and playlists for the same artist share a turn; a true mixed playlist is preferred within its group. When Spotify backfills beside personalized cards, candidates from artists not already represented are preferred. Local-share quotas remain intact. Repeats can still fill remaining spaces if there are too few relevant alternatives; this does not guarantee five different artists when the catalog/history cannot provide them.

Discovery: all five locally ranked artist overviews are queried (previously playlist search used three). Each artist uses a name search and a broader query from available release/related-artist genres, or a related artist mix when genres are unavailable. Up to two candidates per query are sampled using the existing Spotify playlistTracks integration. Sampled tracks must pass the existing seed/related-artist relevance check. Mixed classification requires at least three credited artists with no artist appearing on half the sampled tracks; featured guest names alone do not qualify a dominant-artist playlist. No catalog titles or IDs are fabricated or renamed. Playlist search/sampling has at most three simultaneous requests. Top-15 song metadata lookups remain limited to four simultaneous requests.

Caching: HomeItem.Playlist gains optional artistKey/mixedArtists metadata, persisted in the local Home snapshot. Older JSON remains readable. Older saved This Is [artist], [artist] Mix and [artist] Radio names can be grouped before fresh sample metadata arrives. Home refreshes in the background and keeps saved cards on screen. Complete new candidate variety depends on successful catalog responses; use Home settings Refresh recommendations if desired after installing.

New users retain original Spotify ordering at zero local influence. Local qualified listening (>10 seconds, not Spotify-imported records) still uses the chosen history window, 30 days by default, recency/frequency weighting and extra last-week weight. Maturity and the selected target percentage are unchanged. Listening logs stay local. The Recently played/history rotation keeps its actual activity order. Smart Downloads stays off by default; Stats, playback, queue/Radio behavior, backup, theme, icon and update signing configuration are retained. No user data is reset. Same application ID and version name 1.1; versionCode 49.

Validation: 62 focused Home/recommendation/Stats/JSON tests passed, including ten new diversity cases: balanced artist turns, five-artist coverage despite a dominant candidate pool, real mixed-playlist priority, shared album/playlist artist groups, legacy cached titles, different-artist Spotify backfill, collaborator handling, sample classification, untouched new-user order and optional-field cache compatibility. Updated discovery code compiled against real Spotify model types with platform/auth adapters. Whole-project Kotlin syntax checks passed. Complete build-49 APK compilation and device validation remain pending. Build-46 logs verified Android assembly for that older version; they do not certify build 49. The workflow retains assembleDebug and all app unit tests.

Upload USpot-build-49-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml using build-uspot-49.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . Preserve the existing signing key and install as an update. No GitHub upload/run was performed by the assistant.


# USpot 1.1 — build 50

Home performance: a render-ready layout now lives in HomeViewModel instead of being rebuilt inside Compose whenever Music returns. Reading history/Radio JSON, looking up hidden items, calculating the local influence fraction, selecting the rotation and assembling shelves run on Dispatchers.IO. Hidden keys are read once per preparation. Returning with unchanged inputs reuses the retained layout. Music's scroll state remains retained. Recommendation-cache restoration also runs on IO before the base Home feed is exposed.

Automatic updates remain enabled. Qualified listening signals, changed discovery results, personalization settings, profile-name arrival, Home recents settings, hidden items, collection frequency, Radio seed changes and backup revisions request fresh preparation. The existing minute timer also requests it. The root Home effect stays mounted while Following/Stats are displayed; tab selection itself is not a refresh key. The existing repository still decides when new catalog recommendations need fetching. A timer check does not force different cards or guarantee an online response every minute. The previous layout stays visible until a replacement is ready. This is app/ViewModel lifetime behavior, not an alarm when the application is stopped.

Cancelled/superseded refreshes cannot publish obsolete layouts. Removal immediately filters the visible card, cancels an in-flight layout that could restore it, writes the local exclusion on IO, then requests background backfill. Radio seed persistence completes on IO before navigation; repeated taps are guarded and failure shows a retry message. Stable carousel keys and duplicate filtering avoid duplicate-key failures. The existing current-song highlighting, Radio seed/progress, playback, recommendations and Home shelf selection rules are retained.

No data migration/reset. Same application ID com.music.spotui.modified, namespace, original update-signing configuration and versionName 1.1; internal versionCode 50. The build-49 artist diversity changes, top-15 songs/top-five artists, >10-second local-listening qualification, Spotify-first onboarding, selectable personalization strength up to 100%, local listening privacy, Stats playback, Smart Downloads off by default and all preceding features remain.

Validation:
- 62 existing focused recommendation/Home/cache/Stats tests passed.
- Eight new app unit tests passed for hidden-card backfill, collection-only rotation, Spotify-first fallback, recent-history replacement/limits, duplicate keys, personalized shelf replacement and hidden discoveries.
- Four additional integration tests passed against the actual HomePresentationBuilder/HomeFrequency/HomeRecents implementations with an in-memory Android preferences adapter.
- Eight additional HomeViewModel behavior tests passed with lifecycle/platform/repository and a controlled layout-builder adapter: retained cache, new-input refresh, preference invalidation, immediate removal/backfill request, cancellation of obsolete results, removal during refresh, IO preparation and actual 60-second refresh/listener cleanup. These tests do not exercise an Android Activity lifecycle on a device.
- Changed HomeViewModel and actual presentation builder compiled against Android SharedPreferences/Context APIs with external dependency adapters. Current Home screen/root/feed/header/cards compiled using Compose 1.6.8 and Material3 1.2.1 with navigation/player/repository/platform adapters. The older Android API test jar required a VERSION_CODES.O constant adapter. This is isolated compilation, not an APK build.
- Whole-project Kotlin syntax checks passed. Archive integrity and complete source-file coverage checked during packaging.
- Full local :app:assembleDebug was attempted but Gradle distribution download failed with Network is unreachable. Full build-50 APK compilation, all Gradle unit tests and phone performance/Radio navigation validation remain pending. The supplied GitHub workflow runs assembly and the app unit tests. Successful assembly logs from build 46 do not certify build 50.

Install/build:
1. Upload USpot-build-50-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Do not extract it on GitHub.
2. Replace the contents of .github/workflows/build-spotui-modified.yml with build-uspot-50.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . The workflow explicitly selects build 50's ZIP/versionCode.
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . Download the artifact only after both assembly and unit tests succeed.
4. Preserve the existing signing secrets and install the resulting APK as an update, without uninstalling. Updates require the same installed package ID and signing key. Use Settings data export before updating if desired.
5. USpot-build-50-GitHub-notices.zip contains LICENSE, NOTICE and SOURCE.md; extract and upload these three files to the repository root if keeping public notices alongside the ZIP. They are already present in the complete source and packaged with the APK by the workflow.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 51

Focus: intermittent groups of songs failing stream lookup until waiting or force restarting. Source inspection found concrete blocking/cancellation issues; no device trace was available to prove which one caused the reported incident.

Changes:
- Native YouTube audio resolution no longer performs eager NewPipe signature-timestamp extraction or an eager visitor-data request. The extractor uses a shared synchronized player-JS lock; previously even a native client that needs no signature timestamp waited on it before making its player request.
- Signature timestamps are fetched only for clients that declare they need one. Legacy timestamp/signature/stream extraction uses a bounded single-worker gate: wait at most 2.5 seconds; while that worker remains busy, later calls immediately bypass it rather than creating a backlog. Cancellation interrupts the worker. If a legacy library ignores interruption, the single worker can remain occupied until it exits, but native direct-URL playback is independent. This does not forcibly terminate third-party code.
- Each player endpoint stage has a four-second coroutine budget. Native fallback identities are tried before the more expensive TV/web path. Existing authenticated restricted/private-content paths and client headers are retained. These budgets are part of the existing per-candidate/overall lookup deadlines; they do not guarantee playback on every network.
- Stream URL probes use OkHttp enqueue and cancel their Call when the waiting coroutine is cancelled or their three-second deadline expires. Response bodies are closed. An IO error or inconclusive slow probe lets ExoPlayer attempt the URL, consistent with the old optimistic-network policy. Explicit HTTP rejection/HTML is rejected. The final fallback can no longer hand back a URL whose validation failed. Privately owned tracks keep their existing probe exemption.
- Optional Spotify metadata repair has a 2.5-second budget and uses existing registered metadata if unavailable. Search matching/edition safeguards and source selection are unchanged. Caller cancellation propagates from the resolver instead of being reported as an unavailable track.

Radio recommendations, seed evolution, queue order/history and reopen behavior were not changed, as requested. Home's build-50 retained layout/background updates, earlier recommendations/Stats/download/theme features and existing icon remain. Smart Downloads stays off by default. No data reset or migration; applicationId com.music.spotui.modified, versionName 1.1, versionCode 51. Preserve the existing signing key to install as an update.

Validation:
- 16 focused tests passed: 11 new app unit tests for legacy worker timeout/no backlog, cancellation, error recovery, zero budget, real HTTP audio probing, rejected responses, probe timeout/Call cancellation and parent cancellation; plus five existing stream retry/skip/pause policy tests.
- Seven resolver integration tests passed using the actual changed YTPlayerUtils, actual YouTube client/response model types and real OkHttp local HTTP probes, with external YouTube/NewPipe/token/cipher/Android adapters. They cover native success without legacy JS or visitor requests, native refusal/timeout fallback, cancellation propagation, wrong-video rejection, repeated successful lookups and a cancelled stuck legacy extraction followed by a successful new native lookup. These do not validate live YouTube endpoints, actual WebViews or audio on an Android device.
- Changed optional metadata-repair code compiled in an extracted production-method check against actual Spotify model/API types and Android Log.
- Whole-project Kotlin syntax checks passed; archive integrity and completeness checked. Full local Android assembly was attempted, but the Gradle distribution download failed with Network is unreachable. A full build-51 APK compilation and complete Gradle unit suite remain pending on GitHub, along with phone testing. Focused tests are not proof that every intermittent stream failure is resolved.

Build/install:
1. Upload USpot-build-51-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Keep the ZIP at repository root.
2. Replace .github/workflows/build-spotui-modified.yml using build-uspot-51.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . It explicitly extracts build 51 and verifies versionCode 51.
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . Both :app:assembleDebug and :app:testDebugUnitTest must pass. Download the APK artifact and install as an update without uninstalling. Keep all existing signing secrets.
4. If maintaining visible root notices, extract USpot-build-51-GitHub-notices.zip and upload LICENSE, NOTICE and SOURCE.md to repository root. They already exist in the complete source ZIP and are packaged with the APK by the workflow.

If a failure remains on the phone, capture the installed build, source/quality setting, approximate time and Android logcat for SongPlayer/YTPlayerUtils around the incident. Those details distinguish a resolver stall from network failure, server rejection, authentication or an audio-player buffering error. No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 52

Fixes the GitHub unit-test compilation failure reported in logs_104998140740.zip. The log identifies the exact supplied build-51 source ZIP by SHA-256 41d0a0f59d2da4fc87c622c423dba78c79630db2a5a6f1bde6765b42054ee38e and versionCode 51. :app:assembleDebug succeeded in 4m38s. The following :app:compileDebugUnitTestKotlin failed because StreamLookupIoTest used com.sun.net.httpserver.HttpServer, unavailable in Android's test compiler classpath. Unit tests did not run in that GitHub attempt, and later APK/source artifact packaging/upload steps were skipped.

Change: replace that test's JDK-only HTTP server with a local standard-java ServerSocket fixture. It still sends actual HTTP audio/error responses through the production OkHttp probe and exercises stalled-response cancellation. Fixture sockets and threads are closed, and existing OkHttp cleanup is retained. No test was disabled, no production feature source changed and the workflow still requires both APK assembly and app unit tests before artifact upload.

The build-51 stream fixes, build-50 Home work and all earlier features remain. Radio queue/recommendation behavior is unchanged. No data reset, package change or signing-key change. Same applicationId com.music.spotui.modified and versionName 1.1; versionCode 52.

Validation: 16 focused stream/probe/recovery tests compiled and passed again with Kotlin -Xjdk-release=8, restricting Java references to the public Java 8 API and excluding jdk.httpserver. Whole-project Kotlin syntax checks passed. Packaging verifies every production app/Spotify/InnerTube source file is byte-for-byte identical to build 51; only the test, build/version/workflow and documentation differ. Source ZIP completeness, integrity and workflow/version selection were checked. Build-51 APK assembly is verified by the uploaded log, but build-52's full Android assembly/unit suite still needs a GitHub rerun. There is no phone playback evidence from this build log; it does not prove the intermittent loading issue is resolved.

1. Upload USpot-build-52-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-52.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run: https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
4. Keep the existing signing secrets and install the resulting APK as an update without uninstalling after assembly and all app unit tests pass.
5. USpot-build-52-GitHub-notices.zip contains LICENSE, NOTICE and SOURCE.md for a repository-root notice refresh. These files are already inside the complete source ZIP and packaged with the APK by the workflow.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 53

Response to the report that music no longer resolves after the stream update. This is treated as a regression in builds 51/52. No runtime device log was available to identify the exact failed request; the earlier GitHub log proved build-51 APK compilation, not live audio availability.

Restored behavior:
- TVHTML5 is again the first fallback after the native main client, matching the pre-build-51 order. Build 51 moved that path behind all other native candidates, which could consume the candidate deadline before it was reached.
- Visitor data is initialized before requesting player responses, as in the earlier resolver. Native clients may need consistent visitor context even without a web PoToken.
- Removes build 51's additional four-second per-endpoint cutoff. Existing SongPlayer per-candidate (15 seconds), overall YouTube (45 seconds) and startup (60 seconds) deadlines remain. These are nested budgets, not additive guarantees. Restoring time for a slow usable response can mean a longer wait on a failing source.
- Restores the original last-fallback probe exemption, along with the existing private-track exemption. This lets ExoPlayer try the last fallback's URL instead of discarding every candidate on a preflight rejection. It does not guarantee that the URL will play. Wrong-video/format guards and player buffering/error recovery remain enabled.
- Legacy extraction and optional Spotify metadata repair wait up to eight seconds instead of 2.5, to avoid rejecting cold or slow replies prematurely. The legacy single-worker gate still isolates blocking extraction and avoids a queue of later songs. A busy worker is bypassed; caller cancellation still interrupts it. Existing outer lookup budgets still apply.

Retained: cancellable asynchronous HTTP probes with their three-second optional deadline; cancellation propagation; worker isolation; stream retry/skip/pause safeguards; all earlier Home, library, search, offline, EQ, theme, Stats, signing and data-preservation work. The build-52 standard-socket test compatibility fix is retained. Radio recommendations, station identity, queue evolution/order and history were not changed. Smart Downloads remains opt-in.

Validation:
- 16 focused stream IO/probe/retry tests passed again using Java 8 public APIs.
- Nine integration checks passed against the actual updated YTPlayerUtils and YouTube response/client models, real OkHttp local probes, and external Android/YouTube/NewPipe/cipher/token adapters. Cases include a native response arriving at 4.5 seconds, restored TV-first fallback, visitor context before player lookup, restored final player attempt after preflight rejection, wrong-video rejection, cancellation, repeated lookup and a stuck cancelled legacy worker followed by successful native lookup.
- Updated optional metadata repair compiled in an extracted-production-method check against the real Spotify API/model types and Android Log. Whole-project Kotlin syntax checks and archive integrity/completeness checks passed.
- These checks do not exercise live YouTube endpoints, actual Android WebViews, an installed player or audible output. Build-53 full APK assembly and all Gradle tests still require the supplied GitHub workflow. The older build-51 APK assembly success does not certify this revision. The regression's phone-side resolution is unverified.

Same applicationId com.music.spotui.modified and versionName 1.1; versionCode 53. No data reset or signing changes. Install as an update with the same existing signing key; do not uninstall.

1. Upload USpot-build-53-source.zip unchanged to the repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-53.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and wait for assembly and unit tests before downloading/installing the artifact.
4. If root notices are maintained separately, extract USpot-build-53-GitHub-notices.zip and upload LICENSE, NOTICE and SOURCE.md. They are already inside the source ZIP and packaged with the APK by the workflow.

If playback still fails, a phone-side lookup error/log around one failure and the active source/quality settings are needed to distinguish source rejection, matching, authentication, network timeout and player buffering. GitHub build logs cannot establish those runtime causes. No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 54

A listen now qualifies at AT LEAST 30 seconds (30,000 ms) of audible playback, replacing the earlier more-than-10-second rule. The first qualifying playback-clock tick emits once per visit; buffering, paused time, seek position and suspended polling do not count as audible listening.

A shared ListeningQualification policy is used by ListeningClock, local history qualification, LocalHomePolicy, ListeningTastePolicy, ArtistTastePolicy, HomePersonalization, AdaptiveHomeFeed and Library playlist-song recommendations. Stats and Smart Downloads use the same qualified local-history policy. Home collection-frequency recording and Radio's every-five-qualified-listens progression are triggered by the playback clock and therefore also wait for 30 seconds. Spotify-imported history still does not count as a local qualified listen. Stats empty-state/help wording now says at least 30 seconds. Test fixtures use qualified 30-second listens and explicitly test shorter skips.

Data preservation: no history is cleared or migrated. Old stored entries remain readable/exportable, but entries with less than 30 seconds recorded no longer qualify for the new song/artist recommendation/Stats rules; those counts may decrease. Old entries above the threshold continue to qualify. Previously accumulated collection-frequency totals are retained, since individual historical durations cannot be reconstructed from those aggregates. New collection play counts wait for the new threshold. Favorites, downloads, settings, Radio seed/progress and backup data are retained. Smart Downloads remains off by default.

No stream-resolution change: SongPlayer.kt and YTPlayerUtils.kt are byte-for-byte identical to build 53. Existing two-second next-stream preparation, buffering recovery, source order, timeouts, playback controls and queue rules are unchanged. Same applicationId com.music.spotui.modified, versionName 1.1; versionCode 54. Keep the existing signing key and install as an update without uninstalling.

Validation:
- 81 focused app policy/clock/recommendation/Stats/cache tests passed, including six new qualification tests for 29,999/30,000 ms, shared song/Stats/artist selection, pause/buffering handling, skip isolation and Spotify-import exclusion. Existing clock tests were adjusted to qualify at exactly 30 seconds.
- 17 actual CurrentSongState/history/Smart Downloads integration tests passed with external Android/player/download adapters. They include one history entry updated at qualification, duration updates not double-counting a visit, and retaining an old short history entry while excluding it from taste rankings.
- Changed history, HomePersonalization, AdaptiveHomeFeed, ArtistTastePolicy and clock/policy code compiled together against Android Context/SharedPreferences and JSON/coroutines APIs.
- Whole-project Kotlin syntax checks, source ZIP integrity/completeness and workflow/version matching passed. A source scan found no remaining 10-second local-listen eligibility comparisons in production.
- Full build-54 APK assembly, complete Gradle unit suite and phone playback verification still require GitHub/device testing. Local focused checks do not certify an APK. The previously supplied build-51 assembly log is historical evidence for that older build only.

1. Upload USpot-build-54-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-54.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run: https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow selects build 54 and runs APK assembly and all app unit tests before artifact upload.
4. Install the APK as an update with the existing signing secrets; do not uninstall. USpot-build-54-GitHub-notices.zip contains LICENSE, NOTICE and SOURCE.md if repository-root notices are maintained separately. These are already included in the source ZIP and APK artifact packaging.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 55

## Added in this build

- Home has a top-right + menu: USpot Radio (one song) or USpot Radio Mix (up to five distinct Spotify songs). Search, select songs, optionally name the mix, and create. No seed editor is exposed.
- Each chosen song supplies a recommendation lane. Lanes are interleaved and deduplicated; a failed lane does not discard successful ones. Existing Radio tuning and every-five-qualified-listens evolution remain: original choices stay in the blend alongside the evolving song. Existing current-plus-ten-upcoming queue and protected playback history rules remain.
- Mix names and chosen songs persist. The Radio screen shows the chosen artwork and songs; the saved cover uses the existing four-quadrant generator (fewer than four handled). Home shows saved stations and Library has a Radios filter, including offline access to saved station entries. Recommendations still need network access.
- Automatic repair refreshes an unavailable/old Spotify lookup without changing station name, artwork, original choices or progress. It requires matching title, artist set and explicit status; known durations must be within two seconds. A known ISRC must match; otherwise both durations and album must match. This strict metadata fallback is not absolute recording-identity proof. Ambiguous matches are rejected, not silently replaced with another song. Healthy IDs cache ISRC evidence; checks are spaced 24 hours apart and failed repair attempts have a ten-minute cooldown.
- Recently skipped protection: three distinct manual skips after some audible playback but before 30 seconds, within seven days, temporarily avoid that song in generated Radio/Smart Shuffle recommendations for seven days. Automatic stream failures do not count. Manual playback and ordinary playlist tracks remain available. A deliberate qualified listen clears that song's avoidance. Settings > Playback can disable or reset this protection.
- Settings > Playback adds local diagnostics: last 50 events, Copy report, Clear and Retry song. Reports record fixed stages and sanitized error classes/status codes, not stream URLs, credentials, song queries or listening history. Nothing is automatically uploaded. Diagnostic events are excluded from data export; mix definitions and skip preferences are included.

## Preserved

The 30-second audible-listen rule, Smart Downloads disabled by default, existing Home personalization, Spotify integrations, original icon and prior UI/playback features remain. Existing station records remain readable. Synthetic mix IDs are never sent to Spotify as song IDs or queued as playable tracks. Stream lookup order and timeout policy remain as in builds 53/54; this update adds instrumentation and manual retry, not a promised fix for all upstream stream failures.

Same applicationId `com.music.spotui.modified`, display version `1.1`, internal versionCode `55`. Install using the SAME saved signing key and do not uninstall to preserve app data. Back up important data first. An update signed with another key cannot replace the installed app.

## Validation and limits

- 152 focused automated checks passed: 20 mix/repair/persistence/skip/diagnostics tests, 9 Radio orchestration/Home tests, 81 existing policy/clock/recommendation/cache/Stats tests, 17 state/history/Smart Downloads integration tests, 16 stream-I/O tests and 9 resolver-regression tests. External Android/network/player adapters are used where required; these are not device tests.
- Actual changed ViewModels, Radio API methods and preferences compiled against Android/Spotify/coroutines types with dependency adapters. Actual new Compose controls, Radio screen and Home/Library integration compiled with the Compose compiler and UI adapters. Eleven new pure-policy tests are included in the app's Gradle unit suite; remaining focused harness checks are external validation.
- Whole-project Kotlin syntax and archive/workflow matching were checked. Complete Android assembly and complete Gradle tests could not run locally: Gradle 8.11.1 download fails with Network is unreachable. No build-55 APK or phone playback test has been completed. The workflow runs APK assembly and app unit tests before artifact upload. Earlier build-51 assembly evidence does not certify build 55.
- Spotify recommendation/search/repair availability and latency still depend on the signed-in account and service. If some recommendation lanes fail, the resulting blend may favor the lanes that succeeded. Real authenticated creation, resume, MediaSession skip, audio retry, cover rendering and phone layout need device verification.

## Build from your phone

1. Upload `USpot-build-55-source.zip` unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace `.github/workflows/build-spotui-modified.yml` with the contents of `build-uspot-55.yml`: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-55 APK artifact after success.
4. Keep existing signing secrets. The optional `USpot-build-55-GitHub-notices.zip` contains LICENSE, NOTICE and SOURCE.md for repository-root notices; these are already included in the source ZIP and workflow APK/source artifact.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 56

## Fix

The supplied logs_105186122249.zip confirms that GitHub extracted the exact build-55 source ZIP (SHA-256 156370f5e8b0d977d61917da7136ba5baaedd558d54ae902e151c6d158503b3e). Upload and workflow source selection were correct.

Build 55 failed in :app:compileDebugKotlin at YTPlayerUtils.kt:56 with unresolved references io and response. New diagnostic logging referenced io.ktor.client.plugins.ResponseException directly, while Ktor is declared as an implementation dependency of the InnerTube library and is not visible on the app compile classpath. The earlier isolated compiler harness incorrectly supplied Ktor jars, masking this issue.

Build 56 logs the sanitized exception class name using standard Java instead. No new app dependency is added. Cancellation propagation, stream source order, timeouts, Radio/Mix behavior and all previous features are unchanged. Reports no longer extract HTTP status codes from Ktor exception objects.

All build-55 additions remain: Home + menu for USpot Radio and up-to-five-song Radio Mix, automatic conservative recording lookup repair without a seed editor, repeated-skip protection, local diagnostics with Copy/Retry, artwork collage and Library Radios filter. Same 30-second audible-listen qualification, Smart Downloads off by default, user data, package ID, icon and existing signing configuration.

## Verification

- The actual corrected resolver and diagnostics compiled in the isolated resolver harness with ALL Ktor jars removed from its classpath. Nine resolver regression tests passed. A source scan found no remaining direct io.ktor references in app/src.
- Package comparison checks restrict production changes from build 55 to YTPlayerUtils.kt plus versionCode 56. Other differences are notices, documentation and workflow version selection. Source ZIP CRC, every archived source byte and workflow/notices matching were verified.
- Build-55's 152 focused checks are historical validation for that baseline. This fix reran the nine resolver checks with the narrower classpath; it does not claim that the complete suite or Android APK passed.
- GitHub build 55 failed before APK assembly/unit tests completed, so no build-55 APK success is claimed. Full build 56 remains pending: local Gradle wrapper download still fails with Network is unreachable. Phone playback and UI testing remain required after a successful GitHub build.

## Upload and build

1. Upload USpot-build-56-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-56.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-56 artifact after success.
4. Keep the existing signing secrets and install as an update without uninstalling. Same applicationId com.music.spotui.modified and versionName 1.1; versionCode 56. Different signing keys cannot update the installed app in place.

USpot-build-56-GitHub-notices.zip optionally updates LICENSE, NOTICE and SOURCE.md at repository root. They are already included in the source ZIP and workflow APK/source artifact. No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 57

## Radio creation layout and selection

- Home + is now on the right end of the Your rotation heading, not beside or covering the horizontal filter tabs. This heading/creator remains present even when rotation has no cards, once Home has loaded.
- The dropdown has green station icons, two-line descriptions and themed surfaces. The creator is a full-screen Spotify-inspired layout with a subtle green header gradient, rounded search fields, pill tabs, song artwork, checked selections and a fixed green Create button. Theme colors adapt to light/dark mode and the creator accounts for system bars and the keyboard.
- Your library lists saved/created Spotify playlists and Liked Songs. Opening Liked Songs uses the existing liked-songs repository API; ordinary playlists use their exact Spotify playlist IDs. Albums and the local Downloaded shortcut are excluded. Songs can be filtered within an opened playlist.
- Search Spotify uses the existing Spotify song-search repository. Selections persist while switching between search, playlists and Liked Songs. Tap several song rows to check them, then create once. Radio Mix allows five distinct songs; regular Radio allows one and selecting another replaces it. Selected rows have a green tint and checked circle; removable chips and a count remain visible. A sixth mix selection asks you to uncheck one. Mix naming remains optional.
- Radio play/shuffle/download controls now sit immediately below the mix description, before the chosen-song list and tuning controls. Existing station artwork stays above its title and description.

## Preserved

Build-56's Ktor compilation correction and all prior Radio Mix, automatic conservative recording-lookup repair, skip protection, diagnostics, playback, data export/import and personalization behavior are retained. This update does not change stream lookup policy, recommendations or queue ordering. Playlists are only read for selection; creation of USpot stations does not edit Spotify playlists.

Same applicationId com.music.spotui.modified, versionName 1.1, versionCode 57. Existing user data and signing configuration are retained. Use the SAME signing secrets and install as an update without uninstalling. Smart Downloads remains off by default; local listens still qualify at 30 audible seconds.

## Validation and limits

- Seven focused tests passed using the actual updated RadioCreatorViewModel with Android/repository adapters: playlist filtering/deduplication, Liked Songs endpoint routing, exact playlist-ID routing, cancellation when changing playlists, cancellation when leaving a playlist, Spotify search/error sanitization, and library failure/retry.
- Updated ViewModel compiled with Android/coroutines/Spotify types and dependency adapters. Actual Radio creator/menu, Radio screen and Home integration compiled with the Compose compiler and UI adapters. Changed Kotlin files parse cleanly.
- Archive CRC/completeness, all archived source bytes, workflow/version/notices matching, and changes restricted to the intended four production Kotlin files plus version/docs/workflow were verified against build 56.
- No full build-57 APK, complete Gradle suite or phone layout/authenticated service test has passed yet. Local full assembly is blocked by Gradle wrapper download Network is unreachable. The GitHub workflow assembles the APK and runs the app unit suite before artifact upload. Build-55's reported compiler failure was corrected in build 56 and that correction is preserved.
- Real Spotify playlist/search availability depends on sign-in/network. Existing repository paging loads the first song page as soon as it is available and continues through the playlist. Very large libraries/playlists can take time. This is not a promise of offline Spotify browsing.

## Upload/build

1. Upload USpot-build-57-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-57.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-57 artifact after success.
4. Keep existing signing secrets; install as an update without uninstalling. Optional USpot-build-57-GitHub-notices.zip updates repository-root LICENSE/NOTICE/SOURCE.md; those files are already included in the source and build artifact.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 58

## Radio tuning

- Stay close requests recommendations ONLY for the original song(s). The evolving influence is not requested or blended. Only Spotify track-radio and direct native song-recommendation results are used. If both return no songs, it does NOT fall through to related-artist or profile-based recommendations. It can therefore return fewer/no new songs.
- Balanced gives the original lanes three round-robin rounds for each one evolving round. Every original mix lane gets a turn before that lane's next turn. It does not drain a long evolving-only tail after the originals are exhausted. Direct Spotify song suggestions remain preferred; related-artist fallback is allowed, but broad profile-based fallback is disabled.
- Explore more gives the evolving lane three turns per original round. All original choices still have lanes; existing direct, artist and profile-based fallback paths remain available.
- Weights describe candidate ordering, not a guaranteed audible percentage. Failed/empty lanes, duplicates, exclusions, already-played protection, shuffle and finite result sets affect the actual queue. Each recommendation still comes through the existing Spotify integration. No genre labels, song audio-feature service or new stream provider was added. Similarity is NOT a country-only or other genre guarantee.
- Every-five-qualified-listens progression is retained; Stay close ignores that evolving influence while selected. Switching back to Balanced/Explore can use the saved newer influence. Mix originals, names, covers, saved progress and queue history are retained.

## Live queue behavior and feedback

- Changing tuning refreshes upcoming recommendations while keeping the current song playing and preserving protected playback history. Newer manual refreshes cancel older ones. Taste revision checks reject outdated API/queue results; playback-service refill/end-of-queue paths are guarded too. Cached continuation requests are invalidated by tuning/exclusion changes.
- Existing local Less like this in Radio and Don't play this artist in Radio actions remain in song menus. They filter future candidates and remove excluded upcoming tracks without uploading local feedback to Spotify or deleting playlist/library items. Protected past/current tracks remain. Those actions already existed; this build adds stale-result protection around them.
- Radio screen now shows refresh progress and success/failure messages. If a refresh returns no suitable tracks or fails, the existing queue stays intact with a message instead of silently inserting broader fallbacks. Initial Stay close empty state explains that Balanced allows broader suggestions. Previously queued tracks can remain when a stricter refresh fails; they are not automatically erased.
- Shared legacy RadioTastePolicy.blend delegates to the new blend policy so it cannot retain the old Stay close behavior. Transparent tuning presses remain and selected tuning uses green.

## Preserved

All build-57 creator/UI changes, the build-56 Ktor correction, original icon, existing Spotify authentication/likes/library integration, playback lookup/timeouts, downloads, Home personalization and backups remain. This is a recommendation-policy update, not a stream-loading fix. No local listening history or Radio dislikes/blocks are sent to Spotify to influence its recommendation algorithms.

Same applicationId com.music.spotui.modified, versionName 1.1, versionCode 58. Use the SAME signing secrets and install as an update without uninstalling. Existing user data is retained. Smart Downloads remains off by default and a listen qualifies at 30 audible seconds.

## Validation and limits

- 129 focused checks passed: 28 policy/repair/persistence tests, 13 actual Radio orchestration/Home/feedback tests, 7 actual recommendation-fallback orchestration tests and 81 existing Home/recommendation/clock/Stats/cache/queue tests.
- Eight new pure policy tests are included in the app unit suite; existing tuning expectations were updated for original-only Stay close. Focused external harnesses use Android/repository/service adapters. Source-fallback checks compile and exercise the actual extracted production getRecommendations method, with Ktor jars excluded from that harness.
- Actual updated PlayerViewModel/RadioCreatorViewModel, Radio API methods and preferences compiled with Android/Spotify/coroutines types and dependency adapters. Actual updated Radio screen/tuning controls plus existing creator/Home integration compiled with the Compose compiler and UI adapters. Changed Kotlin files parse cleanly.
- Source ZIP CRC, every archived source byte, allowed changes, and version/workflow/notices matching were verified against build 57. Existing user-data schemas and signing configuration are unchanged.
- Full build-58 APK, complete Gradle suite and phone/real Spotify playback verification remain pending. Local full assembly cannot download Gradle 8.11.1 (Network is unreachable). Isolated compilation and harness tests do not certify an APK. GitHub workflow assembles the APK and runs app unit tests before artifact upload.
- Phone checks after successful build: start a country station in Stay close, switch modes while playing, try a five-song mix, use both exclusion actions, reopen a saved station, and verify audio/current-track/history are preserved. Spotify service results may themselves cross genres; strict genre enforcement is not implemented.

## Upload/build

1. Upload USpot-build-58-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-58.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-58 artifact after success.
4. Keep existing signing secrets; install as an update without uninstalling. Optional USpot-build-58-GitHub-notices.zip updates repository-root LICENSE/NOTICE/SOURCE.md; those are already included in the source and build artifact.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 59

## Per-Radio queues and repetition

Each Radio/Mix now keeps its current song and next ten tracks separately. Playback-state updates save the remaining order and shuffle state; returning to the station loads that order immediately, including offline, and fills missing slots through the existing Spotify recommendation integration. Cached selections are filtered for local exclusions. Changing tuning invalidates the cached upcoming portion and requests suggestions under the new mode. Explicitly pressing shuffle still requests a new shuffle; ordinary Play preserves saved order/shuffle state.

The last active global queue from older builds is copied into per-station storage when restored. Earlier other stations did not have separately saved queues. Their old exact orders and station-specific listening logs cannot be reconstructed. They receive new saved queues as used. Existing global playback history/back navigation remains separate; the per-station cache stores only the current song and ten upcoming songs, not an unlimited stack of past tracks. Per-station playback position is not newly added: the existing global last-session position behavior remains.

A station-local song ID/timestamp record updates only on a new qualified visit (at least 30 audible seconds). It retains each track's latest heard time, rather than full song metadata, artwork, audio or every repeated listen event. Records older than 90 days are removed on memory access/write; limits are 1,000 distinct tracks per station and 10,000 across all stations, oldest first. Radio definitions/names/original choices and general listening history are not deleted by this cleanup.

New recommendation candidates are reordered within each original/evolving lane using weighted randomness, preserving the original-lane blend rules. Songs heard there in the past 24 hours have weight 0.12; one to seven days 0.4; over seven days 0.85; unseen/expired records 1.0. These are ordering weights, not fixed playback percentages. All have nonzero chances: the 90-day log never bans a song. Existing current-song/queue duplicate protection, local disliked songs, blocked artists and repeated-skip protection still apply. Manual playback is unaffected. A restored saved queue is intentionally not randomized on every reopen; newly generated suggestions get the variety ordering.

Queues expire after 90 days and have a separate cap of 32 cached stations or 2 MiB of serialized queue payload, whichever binds first. Oldest caches are evicted without deleting station definitions, last-track memory or original choices. This bounds new queue storage; XML/storage overhead, existing general history, downloads and artwork are separate and are not included in the payload cap. No scheduled background cleanup service is added; expired records are removed when Radio memory is used.

All new data lives in the existing exported radio_progress preference store, so existing backup import/export includes it without resetting old data. No new local history is sent to Spotify to influence its algorithms.

## Visual change

The green music/radio emblem icons are removed from both creation dropdown options and the Radio/Radio Mix creation header. Text labels and the existing page styling remain; actual station artwork and playlist/Liked Songs artwork are retained.

## Preserved and validation

Build-58 Radio tuning/fallback restrictions and stale-request guards, build-57 creator selection/layout, build-56 Ktor correction, original app icon, existing integrations/playback/downloads/Home features remain. No stream resolver policy change. Same applicationId com.music.spotui.modified, versionName 1.1, versionCode 59. Keep existing signing secrets and install as an update without uninstalling. Smart Downloads remains off by default.

157 focused checks passed: 44 policy/persistence tests (including 16 new history/order/cache checks), 19 state/history/Smart Downloads integration checks (including two new actual playback-state save/migration cases), 13 Radio orchestration/Home checks and 81 existing recommendation/cache/Stats/clock tests. Seven new pure RadioMemoryPolicy tests are included in the app Gradle suite. External harnesses use Android/player/repository adapters where necessary. Updated actual ViewModels, playback state, preferences and Radio API methods compiled against Android/Spotify/coroutines types with adapters. Actual creator/Home/Radio Compose code compiled with the Compose compiler and UI adapters. Changed/new Kotlin files parse cleanly.

Source ZIP CRC/completeness, archived bytes and workflow/version/notices matching were checked. Full build-59 APK, complete Gradle suite and phone/authenticated Spotify testing remain pending. Local full assembly cannot download Gradle 8.11.1 (Network is unreachable). Focused checks do not certify an APK. On a phone, test switching between two radios, restarting/updating, saved shuffle order, offline reopening and tuning/exclusions against a previously cached station. Spotify may return a finite/repeated pool; the recent log adds no new prohibition, but existing played-queue protection and available recommendation results still limit a single uninterrupted session. Infinite novel recommendations are not guaranteed.

## Upload/build

1. Upload USpot-build-59-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-59.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-59 artifact after successful APK assembly and app unit tests.
4. Keep the existing signing secrets; install without uninstalling. Optional USpot-build-59-GitHub-notices.zip updates repository-root LICENSE/NOTICE/SOURCE.md, already included in the source/build artifact.

No GitHub upload, workflow run or APK publication was performed by the assistant.


# USpot 1.1 — build 60

## First-song startup recovery

The user reported that after idle/closing the app, the first song can stay silent until skipping away and back. Source inspection found a concrete recovery gap: startStream prepares the player before enabling playWhenReady, while the previous buffering watchdog only armed during onPlaybackStateChanged when playWhenReady was already true. BUFFERING-before-Play can therefore miss the watchdog entirely. This is a plausible contributor to the symptom, not proof of the phone's complete root cause; no diagnostic report from an affected phone was supplied for this pass.

The shared buffering watch is now observed from both playback-state and Play-intent callbacks, plus preloaded-track transitions. Either event order arms the existing 18-second timeout. Duplicate events do not continually restart the deadline. Pause, ready and other non-buffering states cancel it. A new player instance or playback visit gets its own watch.

If playback is still buffering after the deadline, the cached stream URL is invalidated and the same song is resolved again using the existing source selection and startup budget. Recovery checks both player instance and playback-visit ID before applying a result, including the skip-away/back-to-the-same-song case. Saved recovery position is clamped through the existing clock policy. Resolver exceptions and null results reach the existing stream-failure handler instead of silently killing the watcher.

A freshly resolved stream that still buffers is watched again. If it stalls for another 18 seconds, it reaches the existing service retry/skip/pause policy rather than remaining silent indefinitely. Normal pause cancels pending recovery. This is bounded retry behavior, not an immediate-play or guaranteed working-stream promise. Provider outages, lookup-only failures, network reconnection and other playback causes may still exist. Experimental Spotify WebView playback follows its separate engine and is not changed by this ExoPlayer watchdog fix.

startStream also explicitly checks coroutine cancellation before handing audio to the main thread. New local diagnostic stages include Buffering watch armed and Buffering lookup failed; reports remain fixed-stage/sanitized error information without stream URLs, credentials or song queries.

## Preserved

Source-provider order, native/legacy resolver logic, endpoint timeouts, the 60-second startup resolution budget, 18-second buffer deadline, preloading timing and existing failure retry limits are unchanged. No speculative provider reset, authentication change, new network API or blanket longer timeout was added. Build-59 per-station queues/90-day memory, icon removal, all Radio tuning, Home, downloads, likes, settings, backup and other prior changes remain.

Same applicationId com.music.spotui.modified, versionName 1.1, versionCode 60. Existing user data and signing configuration are retained. Keep the SAME signing secrets and install as an update without uninstalling.

## Validation and limits

46 focused checks passed: seven new pure buffering-gate tests, fourteen tests exercising the actual extracted production updateBufferingWatch method with fake player/context/resolver and coroutine scheduler, sixteen existing stream-I/O/recovery checks and nine existing native/fallback resolver regression checks. The fourteen cases cover both startup event orders, duplicate-event deadline retention, pause, healthy ready, skip-away/back visit identity, player replacement, resolver exceptions/empty results, position clamping, pause during lookup, hung lookup deadlines and success/failure after fresh-stream recovery. Pure gate tests are included in the app Gradle unit suite. External runtime tests use adapters and do not execute Android Media3 on a phone.

Changed/new Kotlin files parse cleanly. The extracted recovery method and policy compiled in the focused harness. Full SongPlayer/Android integration compilation, complete Gradle tests, build-60 APK assembly and phone playback verification remain pending: local Gradle 8.11.1 download fails with Network is unreachable. This pass does not claim a fully compiled APK or a confirmed device fix. Source ZIP CRC/bytes/completeness, restricted changes and version/workflow/notices matching are verified.

Phone verification after successful build: let the app sit, return from Bluetooth or relaunch, and play the first restored song without skipping. If it stays silent, wait for automatic recovery. If it still fails, immediately use Settings > Playback > diagnostics > Copy report and share the report; the new watch/recovery stages distinguish an unbuffered resolved stream from lookup failure.

## Upload/build

1. Upload USpot-build-60-source.zip unchanged to repository root: https://github.com/rare621/Spotui/upload/main
2. Replace .github/workflows/build-spotui-modified.yml with build-uspot-60.yml: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and download the build-60 artifact after successful APK assembly and app unit tests.
4. Keep existing signing secrets; install without uninstalling. Optional USpot-build-60-GitHub-notices.zip updates repository-root LICENSE/NOTICE/SOURCE.md, already included in source/build artifact.

No GitHub upload, workflow run or APK publication was performed by the assistant.
