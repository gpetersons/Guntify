package com.music.spotui.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.preferences.RadioSessions
import com.music.spotui.ui.viewmodel.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Spotify recommendation preview. Only the seed is persisted, never this list. */
@Composable
fun RadioScreen(navController: NavController, seedId: String, player: PlayerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val seed = remember(seedId) { RadioSessions.get(context).firstOrNull {
        it.spotifyTrackId == seedId || (it.spotifyTrackId.isBlank() && it.id.toString() == seedId)
    } }
    var tracks by remember(seedId) { mutableStateOf<List<SongsModel>>(emptyList()) }
    var loading by remember(seedId) { mutableStateOf(true) }
    var error by remember(seedId) { mutableStateOf(false) }
    LaunchedEffect(seedId) {
        loading = true
        val result = if (seed?.spotifyTrackId.isNullOrBlank()) emptyList() else
            withContext(Dispatchers.IO) { player.radioRecommendations(seed!!.spotifyTrackId) }
        tracks = result.filter { it.spotifyTrackId != seed?.spotifyTrackId }.distinctBy { it.id }.take(15)
        error = tracks.isEmpty()
        loading = false
    }
    Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { navController.popBackStack() }) { Text("‹ Back") }
        LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 140.dp)) {
            item {
                Text("${seed?.title ?: "Song"} Radio", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Based on ${seed?.title ?: "song"} · ${seed?.singer ?: ""}", color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Button(enabled = seed != null, onClick = { seed?.let { player.startRadioFromSong(it, context) } }) { Text("Play radio") }
                Spacer(Modifier.height(16.dp))
                Text("Up next · 15 songs", style = MaterialTheme.typography.titleMedium)
                if (loading) CircularProgressIndicator(Modifier.padding(20.dp))
                if (!loading && error) Text("Spotify recommendations aren't available right now. Try reopening this radio.", color = Color.Gray)
            }
            itemsIndexed(tracks) { index, track ->
                Column(Modifier.fillMaxWidth().clickable {
                    val queue = listOfNotNull(seed) + tracks
                    player.playSongAt(queue, index + 1, context)
                }.padding(vertical = 11.dp)) {
                    Text(track.title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
                    Text(track.singer, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
            }
            item {
                Spacer(Modifier.height(18.dp))
                Text("Radio will continue as you listen.", color = Color.Gray)
            }
        }
    }
}
