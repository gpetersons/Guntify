# USpot

USpot is rare621’s modified version of Spotui for Android, built with Jetpack Compose.

Original app credit: [Spotui creators and contributors](https://github.com/Spotui/Spotui). USpot is a modified fork released under **GNU GPL version 3**. See [LICENSE](LICENSE), [NOTICE](NOTICE) and [SOURCE.md](SOURCE.md) for the license, dated changes, credits and source/build information. See MODIFIED_VERIFICATION.md for testing limitations and update-signing requirements.

It connects to your real Spotify account and mirrors the Spotify experience:

- 🎵 **Playlists** — browse, play, add/remove tracks, create new playlists, all synced with your Spotify account
- 📝 **Lyrics** — Spotify's own synced lyrics, with a live preview on the player and a full-screen view
- 📻 **Spotify recommendations** — USpot Radio continues with recommendations from the existing Spotify integration; ordinary collections loop, with optional Smart Shuffle additions
- ❤️ Liked songs, followed artists, listening history and downloads (including lossless FLAC)

## Screenshot

<img src="assets/screenshot-player.png" width="360" alt="Now playing screen"/>

## Credits

spotui builds on the work of several open-source projects:

- [Meld](https://github.com/) — Spotify metadata + YouTube streaming layer
- [Neptune](https://github.com/navneet851/spotify-clone-jetpack-compose) — the original Jetpack Compose Spotify clone this app started from
- [SpotiFLAC](https://github.com/spotbye/SpotiFLAC) — lossless (FLAC) track resolving
- [SimpMusic](https://github.com/maxrave-dev/SimpMusic) — crossfade / DJ-style audio filter processing

## Disclaimer

This project is for educational purposes only. Spotify is a trademark of Spotify AB.

## Sharing an APK

Distribute the matching source ZIP with every APK, keep all notices and license files, and provide a clear source link on the download page. The GitHub workflow packages APK, source, LICENSE, NOTICE and SOURCE.md together. Preserve these files when publishing a release; do not rely solely on expiring Actions artifacts.

## USpot build 42

Adds a configurable top-song Smart Downloads set (20 by default), a local Stats tab, existing-playlist/album discoveries for Made For, popularity-based relevant Radio seeds, queue Undo, Radio tuning/exclusions and diamond Smart Shuffle. Smart Shuffle changes the session queue, not the saved Spotify playlist. USpot Radio is a continuous generated queue; Spotify Radio collections retain their playlist behavior.

Smart Downloads updates while the process is available and resumes on launch. Manual downloads are protected; old automatic files remain until replacements are ready. See the matching build notes for validation and account/device testing limits.

## USpot build 43

Restores the last successful personalized Home cards immediately on reopening, then refreshes in the background. Snapshots are scoped to the signed-in session and listening window; logging out clears them. Failed catalog requests retain the previous successful shelf. New users keep Spotify fallback content. Full-player Smart Shuffle has a separate diamond badge, and Radio tuning controls have transparent press feedback. Build 42 features remain included. Full Android compilation and phone checks remain required.

## USpot build 44

Smart Downloads is off by default. Enable it explicitly in Settings. Existing saved choices and downloaded files are preserved. Includes all build-43 changes.

## USpot build 45

Stats now matches Following: cover collage, top-song feature card, transparent controls, Week/Month/All-time filters, play/time/artist totals, last-seven-day activity, playable ranked tracks and artist cards. The selected song starts through the existing player with the displayed top songs queued; song menus and source-scoped playing indicators are included. Rankings use actual qualified local play counts rather than recommendation weighting. Smart Downloads remains off by default and all build-44 features are retained. APK/device validation remains required.

## USpot build 46

Includes the playable Stats redesign and all earlier changes. Recommended playlists replaces Recommended Stations: real Spotify catalog playlists are found from locally weighted songs/artists and their sampled tracks are checked for relevance. Generated USpot Radios remain in Popular radio. Home starts with Spotify data for a new user and gradually increases local influence, following the chosen target percentage. Hidden discoveries backfill before the card limit, collections are deduplicated across the three main shelves, cache refreshes respect settings/account changes, and authenticated mutation retries are time-bounded. Smart Downloads stays off by default. See build notes for validation and remaining device tests.

Local Stats/Following playback queues are not exposed as dead Spotify playlist shortcuts in Home history; real playlists, pinned Liked/Downloaded collections and listening statistics are retained.

## USpot build 47

Fixes a legacy test that assumed Made For was the only returned Home shelf. The test now selects Made For by title and verifies the separate Recommended playlists fallback. Build 46 successfully assembled the Android APK in GitHub Actions; artifact packaging was blocked by this one failing test (180 of 181 tests passed). Build 47 keeps the same application feature code and retains unit-test gating in the workflow. Device testing remains outstanding.

## USpot build 48

Home now uses up to 15 distinct top songs and five top artists. The selected history window, recency/frequency weighting, last-week emphasis and Spotify-first gradual transition are unchanged. Track metadata lookups are capped at four concurrent requests. Existing playlist search still validates candidates for relevance. Smart Downloads, Stats and Radio queue limits are unchanged. Includes the build-47 test correction and all earlier features.

## USpot build 49

Personalized Home shelves give each available artist a turn before repeating one. Real multi-artist playlists are preferred within each artist group, based on sampled Spotify tracks rather than artwork/title alone. Discovery uses all five top artist overviews, searching artist names and relevant genre/related-artist mixes with at most three concurrent playlist lookups. Existing top-15 song inputs, qualification/weighting and Spotify-first transition remain. The cache stores optional artist/mix metadata and still reads previous snapshots. No listening history or saved settings are reset.

## USpot build 50

Home retains a prepared layout when switching Music, Following and Stats or returning from a detail page. History JSON, collection ranking and personalization preparation run on IO workers. Changes to qualified listening, discovery results, Home preferences, hidden items, backup restores and the minute timer request fresh background preparation. The previous layout stays visible until a replacement is ready. Superseded results cannot overwrite newer inputs. Home removal filters immediately and then backfills in the background; Radio seed persistence completes before navigating. Stable carousel keys are deduplicated. User history, settings, signing identity, app ID, existing icon and all prior features are retained. See MODIFIED_VERIFICATION.md for testing limits.

## USpot build 51

Stream loading no longer runs blocking NewPipe player-JS extraction before trying a native audio client. Legacy extraction is isolated behind one worker with a bounded wait and no backlog of later songs. Native fallback clients run before the TV/web path; player endpoint stages have a four-second budget. HTTP audio probes are asynchronous, cancelled with their request, and stop waiting after three seconds. An inconclusive network probe still lets ExoPlayer attempt the URL; explicit HTTP rejection is rejected, including on the last fallback. Optional Spotify playback-metadata repair has a 2.5-second budget and retains registered metadata on failure. Caller cancellation propagates instead of becoming a false track miss. The Radio recommendation/queue rules, Home changes from build 50, user data and signing identity are retained. Complete APK and device validation remain pending; see MODIFIED_VERIFICATION.md.

## USpot build 52

Corrects StreamLookupIoTest to use a standard ServerSocket fixture instead of com.sun.net.httpserver, which was unavailable to Android's Gradle unit-test compiler. The same HTTP validation/cancellation tests remain enabled. User-supplied build-51 logs confirm the exact build-51 APK assembled successfully; its unit-test compilation failed on that fixture, so artifact upload was skipped. Application feature code is unchanged. See MODIFIED_VERIFICATION.md for validation details and limits.

## USpot build 53

Responds to the total lookup failure reported after the stream update. Restores TVHTML5 as the first fallback after the native main client, visitor initialization before player requests, and the original last-fallback probe exemption so ExoPlayer can attempt that URL. Removes the added four-second per-endpoint cutoff; SongPlayer's existing per-candidate/overall/startup deadlines still apply. Legacy extraction and optional Spotify repair waits increase from 2.5 to eight seconds for cold/slow requests. Legacy extraction remains isolated without queuing later lookups, and HTTP probes remain asynchronous/cancellable. Home, Radio recommendations/queue and all other features are unchanged. Tests use the build-52 standard-socket fixture. Device playback is not verified; see MODIFIED_VERIFICATION.md.

## USpot build 54

A local listen now qualifies at 30,000 ms of audible playback instead of more than 10,000 ms. A shared ListeningQualification policy is used by the playback clock, history update path, Home/artist ranking, adaptive recommendations, Stats/Smart Downloads selection and Library playlist-song recommendations. Home collection counts and Radio five-listen seed progression inherit the new clock threshold. Pause/buffering/seek safeguards and two-second stream preparation are unchanged. Existing history remains stored; entries with recorded durations below 30 seconds do not qualify under the new ranking/Stats rules. Previously accumulated collection-frequency totals are retained. Stats wording and timing test fixtures were updated. Stream loading is unchanged from build 53. See MODIFIED_VERIFICATION.md.


## USpot build 55

Home's + menu creates a one-song USpot Radio or a mix of up to five Spotify
songs. Saved stations also appear in Library's Radios filter. Original choices
remain in the recommendation blend while the station evolves. Local repeated-skip
protection and Playback settings diagnostics (Copy report / Retry song) are added.
Lookup repair is automatic and conservatively checks recording metadata; there
is no seed editor. See MODIFIED_VERIFICATION.md for defaults, validation and limits.
Full build-55 APK/device validation remains pending; no new stream fix is claimed.


## USpot build 56

Fixes build 55's compilation failure by removing an app-module Ktor reference
from diagnostic logging. All Radio Mix features and playback behavior remain.
The corrected resolver compiled and nine regression tests passed without Ktor
on the harness classpath; full APK/device validation is pending.


## USpot build 57

Home's Radio + menu moves to the Your rotation heading. A themed full-screen
creator supports Spotify song search, playlists and Liked Songs, with persistent
checked selection (five for Mix, one for Radio). Radio controls sit directly below
the blend description. ViewModel and Compose checks passed; full APK/device
verification is pending. See MODIFIED_VERIFICATION.md for details.


## USpot build 58

Stay close now uses only original-song direct Spotify suggestions, without evolving,
related-artist or profile fallbacks. Balanced favors originals; Explore allows more
evolution. Mix lanes remain interleaved and local feedback/tuning changes invalidate
stale requests. The Radio screen shows refresh status. Genre locking is not promised.
129 focused checks and isolated compilation passed; full APK/device checks are pending.
See MODIFIED_VERIFICATION.md for behavior and validation limits.


## USpot build 59

Each Radio retains its current song and next ten tracks. A capped 90-day local
song-ID/timestamp record favors fresher recommendations with weighted random
ordering, allowing repeats. Old queue caches expire and are size/count limited.
The Radio dropdown/creator emblem icons are removed. Existing user data and
Radio definitions are retained. See MODIFIED_VERIFICATION.md for caps, migration
and validation limits; full APK/device verification remains pending.


## USpot build 60

Repairs a buffering-watch event-order gap on first/restored playback. Recovery
observes both buffering and Play-intent changes, rejects stale visits/players,
and escalates a second stall to the existing failure handler. Stream providers,
source order and timeouts remain unchanged. 46 focused checks passed; full APK
and phone validation remain pending. See MODIFIED_VERIFICATION.md for limits.


## USpot build 61

Hearts/checks now follow each song's identity and observe saved-like preference
changes across the full/mini player and song rows/menus. Automatic transitions
and Spotify library imports no longer rely on pressing next/back to refresh the
indicator. Ten headless Compose checks and Android helper compilation passed;
full APK/device testing remains pending. See MODIFIED_VERIFICATION.md for limits.


## USpot build 62

Home refreshes local history independently of Spotify availability and observes
listening-history preference changes. New collection activity is prioritized;
qualified individual songs appear only in Recently played, never in the top
eight rotation tiles. Existing user data is retained. 28 isolated tests and Home
Android/Compose compilation checks passed; full APK/device testing is pending.
See MODIFIED_VERIFICATION.md for validation limits and installation instructions.


## USpot build 63

Removed collections can return to Home after explicitly replaying and listening
for 30 seconds. Automatic queue continuation does not undo a removal. Collection
listening has a separate clock so starting Radio around an already-qualified
song can count without restarting its stream. 116 isolated tests and partial
Android compilation checks passed; full APK/device testing remains pending.
See MODIFIED_VERIFICATION.md for details and validation limits.


## USpot build 64

Large Recently played cards now contain individual songs only. Collection
history remains in the top eight rotation cards. Local and Spotify fallback
rows both follow this rule. 19 isolated tests passed; full APK/device testing
remains pending. See MODIFIED_VERIFICATION.md for validation limits.


## USpot build 65

Android Auto gains a Recent tab for locally played collections and directly
resumable USpot radios. Library groups Playlists/Albums; Liked Songs and Downloads
remain top-level. Car track selections preserve their collection history and
queue context. 24 isolated checks and Media3 API compilation passed; full APK
and car-device verification remain pending. See MODIFIED_VERIFICATION.md.


## USpot build 66

Adds Android Auto/Assistant song-search entry points, manual queue priority
(next, in added order) and a shared “Added to queue” popup. 48 isolated tests
and partial Kotlin/Media3/Compose compilation checks passed. Full APK and
car-device verification remain pending. See MODIFIED_VERIFICATION.md.


## USpot build 67

Search song taps use ordinary playback rather than creating a Radio. Android
Auto gains a Recent radios tab for USpot stations and recently played catalog
radio-named playlists; Downloads moves under car Library. 55 isolated checks
and partial compilation passed; full APK and car testing remain pending.
See MODIFIED_VERIFICATION.md.


## USpot build 68

Stream failures receive two retries with ten-second backoff, then one skip;
the next song keeps retrying instead of exhausting the queue or pausing.
User actions cancel pending work. 76 isolated checks and partial compilation
passed; full APK/network-loss/device testing remains pending.
See MODIFIED_VERIFICATION.md.
