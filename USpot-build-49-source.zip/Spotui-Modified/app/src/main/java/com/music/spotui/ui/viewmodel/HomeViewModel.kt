package com.music.spotui.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.spotui.data.api.Response
import com.music.spotui.data.entity.AlbumsModel
import com.music.spotui.data.entity.ArtistsModel
import com.music.spotui.data.entity.HomeFeedModel
import com.music.spotui.ui.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: AppRepository)  : ViewModel() {


    private val _albums : MutableStateFlow<Response<List<AlbumsModel>>> = MutableStateFlow(Response.Loading())
    val albums : StateFlow<Response<List<AlbumsModel>>> = _albums

    private val _artists : MutableStateFlow<Response<List<ArtistsModel>>> = MutableStateFlow(Response.Loading())
    val artists : StateFlow<Response<List<ArtistsModel>>> = _artists

    private val _home : MutableStateFlow<Response<HomeFeedModel>> = MutableStateFlow(Response.Loading())
    val home : StateFlow<Response<HomeFeedModel>> = _home


    private val _discovery = MutableStateFlow(repository.cachedHomeDiscoveries())
    val discovery: StateFlow<List<com.music.spotui.data.entity.HomeSection>> = _discovery

    private val _following = MutableStateFlow<Response<com.music.spotui.data.entity.FollowingFeed>>(Response.Loading())
    val following: StateFlow<Response<com.music.spotui.data.entity.FollowingFeed>> = _following
    private var followingJob: kotlinx.coroutines.Job? = null
    fun loadFollowing(refresh: Boolean = false) {
        if (followingJob?.isActive == true || (!refresh && _following.value is Response.Success)) return
        _following.value = Response.Loading()
        followingJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                _following.value = Response.Success(repository.provideFollowingFeed { partial -> _following.value = Response.Success(partial) })
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _following.value = Response.Error(error.message ?: "Couldn't load followed artists.")
            }
        }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val timer = MutableStateFlow(0L)
            launch { while (true) { delay(60_000L); timer.value++ } }
            combine(com.music.spotui.data.preferences.ListeningHistorySignals.revision,
                com.music.spotui.data.preferences.HomePersonalization.revision, timer,
                com.music.spotui.data.preferences.RadioTaste.revision, BackupSignals.revision) { _, _, _, _, _ -> Unit }.collect {
                kotlinx.coroutines.delay(1000L)
                try {
                    _discovery.value = repository.discoverHomeCollections()
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    android.util.Log.w("HomeViewModel", "Local discoveries unavailable", error)
                }
            }
        }
        fetchHome()
        fetchArtists()
        fetchAlbums()
    }

    private fun fetchDiscovery() = viewModelScope.launch(Dispatchers.IO) {
        runCatching { repository.discoverHomeCollections() }
            .onSuccess { _discovery.value = it }
    }

    private fun fetchHome() = viewModelScope.launch(Dispatchers.IO) {
        repository.provideHomeFeed().collect { feed ->
            _home.value = feed
        }
    }

    private fun fetchAlbums() = viewModelScope.launch(Dispatchers.IO) {
            repository.provideAlbums().collect{ album ->
                _albums.value = album as Response<List<AlbumsModel>>
            }
    }

    private fun fetchArtists() = viewModelScope.launch(Dispatchers.IO) {
        repository.provideArtists().collect { artist ->
            _artists.value = artist as Response<List<ArtistsModel>>
        }
    }



}
