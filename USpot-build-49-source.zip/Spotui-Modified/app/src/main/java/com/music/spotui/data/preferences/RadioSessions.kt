package com.music.spotui.data.preferences

import android.content.Context
import com.music.spotui.data.entity.SongsModel
import org.json.JSONArray
import org.json.JSONObject

/** Local radio seeds, ordered newest first. Never sent to Spotify. */
object RadioSessions {
    private const val PREF = "spotui_radio_sessions"
    private const val KEY = "seeds"
    private fun encode(song: SongsModel) = JSONObject().apply {
        put("id", song.id); put("title", song.title); put("album", song.album)
        put("singer", song.singer); put("cover", song.coverUri); put("url", song.url)
        put("spotify", song.spotifyTrackId); put("explicit", song.explicit)
        put("duration", song.durationMs)
    }
    fun get(context: Context): List<SongsModel> = runCatching {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]")
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            SongsModel(o.optInt("id"), o.optString("title"), o.optString("album"),
                o.optString("singer"), o.optString("cover"), o.optString("url"),
                o.optString("spotify"), o.optBoolean("explicit"), o.optInt("duration"))
        }
    }.getOrDefault(emptyList())
    fun remember(context: Context, song: SongsModel) {
        HomeFrequency.played(context, "radio", song.spotifyTrackId.ifBlank { song.id.toString() }, song.title + " Radio", song.coverUri, song.singer)
        val items = (listOf(song) + get(context).filterNot {
            if (song.spotifyTrackId.isNotBlank()) it.spotifyTrackId == song.spotifyTrackId else it.id == song.id
        })
        val arr = JSONArray().apply { items.forEach { put(encode(it)) } }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
    private const val PROGRESS = "radio_progress"
    private fun key(seedId: String) = "last_" + seedId
    fun lastTrack(context: Context, seedId: String): SongsModel? = runCatching {
        val raw = context.getSharedPreferences(PROGRESS, Context.MODE_PRIVATE).getString(key(seedId), null)
            ?: return@runCatching null
        val o = JSONObject(raw)
        SongsModel(o.optInt("id"), o.optString("title"), o.optString("album"),
            o.optString("singer"), o.optString("cover"), o.optString("url"),
            o.optString("spotify"), o.optBoolean("explicit"), o.optInt("duration"))
    }.getOrNull()
    fun saveLastTrack(context: Context, seedId: String, track: SongsModel) {
        if (seedId.isBlank()) return
        context.getSharedPreferences(PROGRESS, Context.MODE_PRIVATE).edit()
            .putString(key(seedId), encode(track).toString()).apply()
    }

    fun recommendationSeed(context: Context, stationId: String): String =
        context.getSharedPreferences(PROGRESS, 0).getString("recommendation_" + stationId, stationId) ?: stationId
    @Synchronized
    fun qualified(context: Context, stationId: String, track: SongsModel, visit: String): Boolean {
        if (track.spotifyTrackId.isBlank()) return false
        val prefs = context.getSharedPreferences(PROGRESS, 0)
        val previous = com.music.spotui.data.recommendation.EvolvingRadioPolicy.Progress(
            recommendationSeed(context, stationId), prefs.getInt("count_" + stationId, 0), prefs.getString("visit_" + stationId, "").orEmpty())
        val next = com.music.spotui.data.recommendation.EvolvingRadioPolicy.qualify(previous, track.spotifyTrackId, visit)
        if (next == previous) return false
        prefs.edit().putString("recommendation_" + stationId, next.seed).putInt("count_" + stationId, next.count)
            .putString("visit_" + stationId, next.visit).apply()
        return next.seed != previous.seed || (next.count == 0 && previous.count == 4)
    }

}
