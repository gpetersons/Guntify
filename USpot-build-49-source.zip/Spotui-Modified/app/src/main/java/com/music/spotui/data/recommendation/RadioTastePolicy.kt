package com.music.spotui.data.recommendation
import com.music.spotui.data.entity.SongsModel
import java.util.Locale

object RadioTastePolicy {
    fun allowed(song: SongsModel, dislikes: Set<String>, blocked: Set<String>): Boolean {
        if (song.spotifyTrackId.ifBlank { "local:${song.id}" } in dislikes) return false
        return song.singer.lowercase(Locale.ROOT).split(Regex(",| feat\\. | ft\\. ")).map { it.trim() }.none { it in blocked }
    }
    fun blend(seeds: List<String>, batches: List<List<SongsModel>>, mode: String): List<SongsModel> {
        if (mode !in setOf("close", "explore") || batches.size < 2) return DualSeedRadioPolicy.blend(seeds, batches)
        val weights = if (mode == "close") listOf(3, 1) else listOf(1, 3)
        val pointers = IntArray(batches.size)
        val seen = seeds.toMutableSet()
        val result = mutableListOf<SongsModel>()
        while (batches.indices.any { pointers[it] < batches[it].size }) {
            batches.forEachIndexed { i, batch -> repeat(weights.getOrElse(i) { 1 }) {
                if (pointers[i] < batch.size) {
                    val song = batch[pointers[i]++]
                    if (seen.add(song.spotifyTrackId.ifBlank { "local:${song.id}" })) result += song
                }
            } }
        }
        return result
    }
}
