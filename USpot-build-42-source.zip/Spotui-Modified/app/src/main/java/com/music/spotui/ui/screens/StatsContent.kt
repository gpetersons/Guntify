package com.music.spotui.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.music.spotui.data.preferences.*
import com.music.spotui.data.recommendation.ListeningTastePolicy
import com.music.spotui.ui.theme.*

@Composable
fun StatsContent() {
    val context = LocalContext.current
    val playsRevision by ListeningHistorySignals.revision.collectAsState()
    val timeRevision by ListeningStatsSignals.revision.collectAsState()
    val backupRevision by com.music.spotui.ui.viewmodel.BackupSignals.revision.collectAsState()
    var days by rememberSaveable { mutableStateOf(30) }
    val history = remember(playsRevision, timeRevision, backupRevision) { getListeningHistory(context) }
    val now = System.currentTimeMillis()
    val entries = ListeningTastePolicy.qualified(history, now, days)
    val songs = ListeningTastePolicy.topSongs(history, now, 10, days = days)
    val artists = ListeningTastePolicy.artistCounts(history, now, days).take(10)
    val minutes = entries.sumOf { it.listenedMs } / 60_000
    Column(Modifier.fillMaxSize().background(AppBackground).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Your listening", color = AppText, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Your music in USpot", color = AppSecondary, modifier = Modifier.padding(vertical = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 14.dp)) {
            listOf(7 to "Week", 30 to "Month", 0 to "All time").forEach { (value, label) ->
                Text(label, color = if (days == value) AppBackground else AppText,
                    modifier = Modifier.background(if (days == value) AppPalette else AppRaised, RoundedCornerShape(24.dp)).clickable { days = value }.padding(16.dp, 10.dp))
            }
        }
        Text("${entries.size} plays · ${minutes / 60}h ${minutes % 60}m recorded", color = AppPalette, fontSize = 20.sp,
            modifier = Modifier.fillMaxWidth().background(AppSurface, RoundedCornerShape(18.dp)).padding(20.dp))
        if (entries.isEmpty()) Text("Listen for more than 10 seconds to start building your stats.", color = AppSecondary, modifier = Modifier.padding(vertical = 24.dp))
        Text("Top songs", color = AppText, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp))
        songs.forEachIndexed { index, song ->
            Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text("${index + 1}. ${song.title}", color = AppText, fontSize = 17.sp)
                Text(song.singer, color = AppSecondary, fontSize = 14.sp)
            }
        }
        Text("Top artists", color = AppText, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp))
        artists.forEachIndexed { index, (name, count) -> Text("${index + 1}. $name · $count plays", color = AppText, modifier = Modifier.padding(vertical = 10.dp)) }
        Text("Local USpot plays only. Older history may contain only the first qualifying seconds; detailed listening time is recorded from this update onward.", color = AppSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 24.dp))
        Spacer(Modifier.height(com.music.spotui.ui.navigation.LocalBottomOverlayInset.current + 32.dp))
    }
}
