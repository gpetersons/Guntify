package com.music.spotui.data.recommendation
import com.music.spotui.data.entity.SongsModel
object EvolvingRadioPolicy {
    data class Progress(val seed: String, val count: Int = 0, val visit: String = "")
    fun qualify(previous: Progress, trackId: String, visit: String): Progress {
        if (trackId.isBlank() || visit == previous.visit) return previous
        val count = (previous.count.coerceIn(0, 4) + 1) % 5
        return Progress(if (count == 0) trackId else previous.seed, count, visit)
    }
    fun window(queue: List<SongsModel>, currentId: Int): List<SongsModel> {
        val index = queue.indexOfFirst { it.id == currentId }.coerceAtLeast(0)
        return queue.drop(index).distinctBy { it.id }.take(11)
    }
    fun fill(current: SongsModel, previous: List<SongsModel>, candidates: List<SongsModel>, rotate: Boolean): List<SongsModel> {
        val index = previous.indexOfFirst { it.id == current.id }
        val upcoming = if (index < 0) emptyList() else previous.drop(index + 1)
        val oldIds = previous.map { it.id }.toSet()
        val fresh = candidates.filter { it.id != current.id && it.id !in oldIds }.distinctBy { it.id }
        val next = if (rotate) fresh.take(10).shuffled() + upcoming + candidates else upcoming + fresh + candidates
        return listOf(current) + next.filter { it.id != current.id }.distinctBy { it.id }.take(10)
    }
}
