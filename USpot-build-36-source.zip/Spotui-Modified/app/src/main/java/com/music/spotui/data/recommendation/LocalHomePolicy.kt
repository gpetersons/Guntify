package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.HomeItem
import com.music.spotui.data.entity.HomeSection
import java.util.Locale
import kotlin.math.exp

data class LocalTasteSample(val trackId: String, val artists: String, val timestamp: Long, val listenedMs: Long, val source: String)

object LocalHomePolicy {
    const val ALBUMS = "local-home-albums"
    const val ARTIST_RADIOS = "local-home-artist-radios"
    const val SONG_RADIOS = "local-home-song-radios"
    private const val DAY = 86_400_000L
    fun qualifying(samples: List<LocalTasteSample>, now: Long, windowDays: Int = 30) = samples.filter {
        it.source != "spotify" && it.listenedMs > 10_000L && it.timestamp <= now && (windowDays <= 0 || now - it.timestamp <= windowDays.toLong() * DAY)
    }
    private fun weight(sample: LocalTasteSample, now: Long): Double {
        val age = (now - sample.timestamp) / DAY.toDouble()
        return exp(-age / 14.0) * if (age <= 7.0) 3.0 else 1.0
    }
    fun topTracks(samples: List<LocalTasteSample>, now: Long, windowDays: Int = 30): List<String> = qualifying(samples, now, windowDays)
        .filter { it.trackId.isNotBlank() }.groupBy { it.trackId }.entries
        .sortedWith(compareByDescending<Map.Entry<String, List<LocalTasteSample>>> { it.value.sumOf { sample -> weight(sample, now) } }.thenBy { it.key })
        .take(5).map { it.key }

    fun topArtists(samples: List<LocalTasteSample>, now: Long, windowDays: Int = 30): List<String> {
        val names = linkedMapOf<String, String>()
        val scores = linkedMapOf<String, Double>()
        qualifying(samples, now, windowDays).forEach { sample ->
            sample.artists.split(Regex(",| feat\\. | ft\\. ", RegexOption.IGNORE_CASE)).map { it.trim() }
                .filter { it.isNotBlank() }.distinctBy { it.lowercase(Locale.ROOT) }.forEach { name ->
                    val key = name.lowercase(Locale.ROOT)
                    names.putIfAbsent(key, name)
                    scores[key] = (scores[key] ?: 0.0) + weight(sample, now)
                }
        }
        return scores.entries.sortedWith(compareByDescending<Map.Entry<String, Double>> { it.value }.thenBy { it.key })
            .take(5).map { names.getValue(it.key) }
    }

    private fun kind(title: String): String? = when {
        title.trim().startsWith("Made for ", true) -> ALBUMS
        title.trim().equals("Recommended Stations", true) -> ARTIST_RADIOS
        title.trim().equals("Popular radio", true) -> SONG_RADIOS
        else -> null
    }
    private fun id(item: HomeItem): String = when (item) {
        is HomeItem.Album -> "album:${item.name.lowercase(Locale.ROOT)}|${item.artists.lowercase(Locale.ROOT)}"
        is HomeItem.Radio -> "radio:${item.seed.spotifyTrackId}"
        is HomeItem.Playlist -> "playlist:${item.id}"
        is HomeItem.Artist -> "artist:${item.id}"
        is HomeItem.RecentTrack -> "track:${item.song.spotifyTrackId}"
    }
    /** Three concise shelves plus the separately required Recently played row. */
    fun shelves(original: List<HomeSection>, discoveries: List<HomeSection>, fraction: Double): List<HomeSection> {
        val defaults = listOf("Made for you" to ALBUMS, "Recommended Stations" to ARTIST_RADIOS, "Popular radio" to SONG_RADIOS)
        val usedRadios = mutableSetOf<String>()
        val result = defaults.mapNotNull { (fallbackTitle, category) ->
            val row = original.firstOrNull { kind(it.title) == category }
            val local = discoveries.firstOrNull { it.title == category }?.items.orEmpty()
                .filter { if (category == ALBUMS) it is HomeItem.Album else it is HomeItem.Radio && id(it) !in usedRadios }.distinctBy(::id).take(5)
            val spotify = row?.items.orEmpty().distinctBy(::id).take(5)
            val share = fraction.coerceIn(0.0, 0.7)
            val count = (5 * share).toInt().coerceAtMost(local.size)
            val additions = if (spotify.isEmpty() && share > 0.0) local else local.take(count)
            val merged = (additions + spotify.filter { old -> additions.none { id(it) == id(old) } }).distinctBy(::id).take(5)
            merged.filterIsInstance<HomeItem.Radio>().forEach { usedRadios.add(id(it)) }
            if (merged.isEmpty()) null else HomeSection(row?.title ?: fallbackTitle, merged)
        }
        val recentlyPlayed = original.firstOrNull { it.title.equals("Recently played", true) && it.items.isNotEmpty() }
        return listOfNotNull(recentlyPlayed) + result
    }
}
