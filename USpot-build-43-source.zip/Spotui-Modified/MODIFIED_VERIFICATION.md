# USpot 1.1 — backup/import and build corrections

Display version remains 1.1; internal Android versionCode advances to 23. Application ID, icon, data directories, and the permanent signing-key setup are unchanged.

## Uploaded build log

The provided Actions run successfully passed the signing-key restore step. It then failed at app:compileDebugKotlin because HomeScreen.kt did not import mutableStateOf. The missing import is corrected.

The log also contained repeated D8 warnings about Kotlin metadata compatibility. This source updates Android Gradle Plugin from 8.4.2 to 8.10.1 and the Gradle wrapper from 8.6 to 8.11.1, retaining Kotlin 2.2.0. The matching workflow explicitly installs Build Tools 35.0.0 and the Android 34 platform. Official compatibility references:
https://developer.android.com/build/kotlin-support
https://developer.android.com/build/releases/agp-8-10-0-release-notes

## New Settings → Data & backup

- Export backup opens Android's Save file picker and writes a USpot backup ZIP outside the app, wherever the user chooses.
- Import backup opens Android's file picker, asks before replacing backed-up local data, pauses playback, and restores the selected archive.
- The backup includes local listening history, likes, saved library/cache data, Home personalization/history/removals, Radio seeds and resume progress, queue/playback position, EQ/appearance/settings, alternative stream choices, and playlist cover files.
- Include downloaded audio is enabled by default and can be disabled for a smaller archive. Download index entries are restored only when their referenced audio files actually exist.
- External local-music file references are retained, but Android file/folder permissions must be granted again after reinstalling or switching devices. The external audio itself is not copied into this backup.
- Passwords, login cookies, access/session tokens, Soulseek usernames, Spotify/SpotiFLAC authentication stores, and private signing keys are excluded. Existing login credentials in the destination installation are preserved. Restore does not submit changes to Spotify.
- Archives use a versioned manifest, explicit file list, byte lengths, and SHA-256 checksums. They are extracted into staging first with path, metadata-size, entry-count, and available-space checks. Validation finishes before live data is replaced. Ordinary restore errors attempt to roll back changed preferences and files.
- Import reloads runtime download/EQ/appearance/playback state and refreshes Settings/Home. Playback stays paused after restore.
- Current downloads must finish before export, preventing active download files from being backed up mid-write.

This feature cannot recover private data from the currently installed old-signed app that has no export button. It protects future installations once this version is installed and a backup is successfully exported. Do not uninstall the old app under the assumption that this new code has already backed it up.

Keep backups private: they contain personal listening history and settings, although account credentials are excluded. Keep the ZIP outside the app so uninstalling does not remove it. Export a backup before restoring another archive if you need to preserve the current local data.

## Validation

- 34 JVM tests passed: all previous policy tests plus backup audio/metadata round-trip, hashes, unsafe-path rejection, extraction quota, malformed archive rejection, and authentication exclusions.
- Four additional codec tests passed against production backup code, covering exact integer/long values, Boolean/Float/String settings, string sets, and rejected unknown types. Total: 38 passing tests.
- All 232 Kotlin source files passed syntax parsing.
- The production backup backend compiled in isolation against Android API classes and org.json; this is not a full Android app build or device test.
- Full Android assembleDebug was attempted using the updated wrapper, but the local environment could not reach the Gradle distribution URL. No new APK was produced here.
- SAF file-picker behavior, permissions, rollback on Android storage failures, runtime refresh, UI, authenticated Spotify features, and install/update behavior still require a successful Actions build and device testing. No claim is made that backup/restore has passed an Android device test.
- Original icon assets remain byte-identical. The complete source ZIP passed integrity checks and includes all preceding USpot modifications.

## Upload/build from your phone

1. Upload USpot-1.1-backup-source.zip unchanged to:
https://github.com/rare621/Spotui/upload/main
2. Replace the existing workflow contents with build-uspot-backup.yml:
https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Keep the EXISTING USPOT_SIGNING_KEYSTORE_BASE64 secret and permanent keystore. Do not generate another key.
4. Run:
https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
5. After both build and tests succeed, download USpot-1.1-APK from Artifacts.

## Phone verification

Export to Downloads with audio, then confirm that the ZIP exists and has a sensible size. Import into a test/fresh installation and compare history, likes, Radio sessions, settings/EQ, covers, and downloaded playback. Check exports without audio, canceled pickers, an unrelated ZIP, corrupted files, insufficient storage, and restoring while music had been playing. After establishing the permanent-key installation, future APKs must install as updates without uninstalling; verify data is still present after one such update.


# USpot 1.1 — build 43

Complete cumulative source based on build 42. All 352 previous source files are retained. Added Home snapshot storage and its unit tests; existing playback, Smart Downloads, Stats, queue Undo, Radio tuning, Smart Shuffle, personalization, Library, backup, equalizer, theme and licensing changes are preserved.

Home startup: the last successful Spotify base feed and personalized discovery shelves are saved locally. The ViewModel restores discovery shelves before the first Home render; the base feed is emitted from storage before network requests. The signed-in account's section titles, item ordering, Spotify IDs and playable Radio seeds survive restart. Refreshes happen in the background; an empty failed shelf retains the previous successful shelf. Personalization settings and listening window remain respected. New users retain Spotify fallbacks. One successful load after installing this build is needed to populate the new cache. Existing artwork caching is unchanged; cold image downloads can still take time.

Account changes/logouts clear the snapshots, and the codec checks a one-way session fingerprint and history-window scope. No credentials or listening history are added to network requests. Cache data is expendable and is not added to exported backups; the user's actual listening history and settings remain in the existing backup system. Package ID and signing configuration remain unchanged; versionCode is 43, display version 1.1. Keep the existing signing key and install as an update.

Player: Smart Shuffle diamond is outside the shuffle glyph, positioned as a separate upper-right badge within a 48dp transparent touch target; accessibility descriptions identify off/on/Smart modes.

Radio tuning: Stay close, Balanced and Explore more have no gray ripple/press highlight. Selection remains green with a transparent background.

Validation: seven new production-code JSON/policy tests passed (all Home item types, ordering/title/ID preservation, account/window rejection, malformed/future format, retaining good shelves and successful replacements). Four storage-adapter tests passed (persisted read, account isolation, empty-result protection and logout clearing). Whole-project Kotlin syntax checks and Android resource compilation also passed; the updated discovery method compiled against the actual Spotify models. These are JVM/source checks, not Android phone tests. Full Android compilation was attempted but stopped before configuration because the Gradle wrapper could not reach services.gradle.org (Network is unreachable). UI appearance, actual cold launch, Bluetooth/Android Auto and authenticated Spotify account operations still require APK/device testing. Earlier build-42 focused test results remain documented separately and are not a substitute for this build's APK test.

Upload USpot-build-43-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-43.yml using https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow compiles/tests the Android project and bundles APK, exact source ZIP and license notices. This build has not been uploaded or run on GitHub by the assistant; connector writes were previously rejected with HTTP 403.
