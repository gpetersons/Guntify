package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.SongsModel

/** Radio recommendations always retain the original seed; resuming only changes the first track. */
object RadioQueuePolicy {
    fun seeds(originalSeed: String?, queue: List<SongsModel>): List<String> =
        originalSeed?.takeIf { it.isNotBlank() }?.let { listOf(it) }
            ?: queue.takeLast(5).map { it.spotifyTrackId }.filter { it.isNotBlank() }.distinct()

    private fun key(song: SongsModel) = song.spotifyTrackId.ifBlank { "local:${song.id}" }
    fun resumed(seed: SongsModel?, last: SongsModel?, suggestions: List<SongsModel>, rotation: Int = 0): List<SongsModel> {
        val first = last ?: seed
        val candidates = suggestions.filter { key(it) != first?.let(::key) && key(it) != seed?.let(::key) }.distinctBy(::key)
        val offset = if (candidates.isEmpty()) 0 else Math.floorMod(rotation, candidates.size)
        return (listOfNotNull(first) + candidates.drop(offset) + candidates.take(offset)).distinctBy(::key).take(15)
    }
}
