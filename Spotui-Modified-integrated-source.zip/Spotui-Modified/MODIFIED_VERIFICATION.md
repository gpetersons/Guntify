# Spotui Modified 1.6.1 — verification and handoff

This is an updated source package, not a verified Android release. No APK was produced here.

## Source baseline

- Inspected the attached `Spotui-Modified-radio-download-shuffle-source.zip` and its matching workflow.
- Compared it with `rare621/Spotui` at commit `c3286609bc865fde486f6abbffe86e65790238db`.
- The attached ZIP contained Radio, Radio download controls, Home history, local ranking, and catalog discovery changes absent from the repository's normal source tree. It was used as the baseline.
- Application ID remains `com.music.spotui.modified`; namespace remains `com.music.spotui` for existing source/resource compatibility.
- Version code is 17, version name is 1.6.1. All 18 original launcher/icon files are byte-for-byte unchanged.

## What the updated code contains

| Area | Source changes | Verification limit |
|---|---|---|
| Radio | Shared original-seed policy for service and player continuation; resume track first; deduplicated queue capped at 15; permanent seed storage no longer capped at eight; original download manager retained | Pure queue/seed rules tested; live Spotify results, offline download, and playback transitions require a phone |
| Radio and playback races | New queue ownership resets Radio tracking and shuffle; generation checks reject results from replaced sessions; queued additions preserve the active Radio | Service, crossfade, and rapid skipping require device tests |
| Home history | Long-press removal dialog; local exclusion store; older local collections and Spotify fallback backfill up to eight shortcuts; songs/artists excluded from shortcut grid; separate Recently played row retained | Compose rendering, long-press, and backfill need device tests; fewer than eight eligible collections produce fewer cards |
| Adaptive Home | Frequency/recency weighting retained; explicit maturity stages; catalog searches cover playlists, albums, artists, and songs, plus genres when Spotify returns genre metadata; existing section titles retained; time-sensitive release rows protected | Live ranking, available catalog types, and section semantics need signed-in tests |
| Library removal | Horizontal swipe in list and grid opens confirmation; albums are unsaved and playlists are unfollowed through original library mutation; local cache changes only after server-reported success | Account permissions and current Spotify mutation behavior require live tests; no playlist contents are deleted |
| Create playlist | Library plus button and name prompt; original Spotify creation integration; mixed Spotify/local song suggestions; add-song controls; four-quadrant cover with repeated artwork for fewer than four songs | Create/add/cover upload need signed-in testing; local cover is retained when upload fails |
| Profile/settings | Current account avatar/details; Playback, Music sources, Home, Account, About menus preserve existing controls; modified credit retained | Account-switch behavior and settings navigation need device tests |
| Equalizer | On/off and Normal, Bass Boost, Rock, Pop, Classical, Vocal; Android Equalizer binds to each player's actual audio session, including crossfade player; releases effects with players | No audio hardware tested; output/device support may vary; does not attach to global session zero |
| Shuffle | Playlist, album, liked songs, artist, local collections, and Radio read shared playback state for green/white icons; active shuffle can be disabled | Visual state, queue order restoration, and crossfade behavior need phone tests |
| Spotify song likes | Reused original add/remove-library functions; connected legacy album/search/artist/liked-album row buttons that previously changed only local state; serialized remote save operations; visible failure feedback | No authenticated Spotify account tested; failure leaves the local like state and reports that Spotify did not synchronize |

Spotify local listening history remains local. Discovery queries use selected artist/genre names and recommendation seed IDs to retrieve catalog results; they do not upload the listening log or report Spotui playback as Spotify listening activity. Explicit library/playlist/like actions still make the requested Spotify mutations.

## Personalization assumptions

Maturity uses eligible locally logged playback starts within the selected history window, excluding imported Spotify plays:

| Local play entries | Spotify target | Local target |
|---|---:|---:|
| 0–2 | 100% | 0% |
| 3–19 | 80% | 20% |
| 20–59 | 60% | 40% |
| 60–149 | 40% | 60% |
| 150+ | 30% | 70% |

The thresholds were chosen because the handoff specified percentages but no play-count boundaries. The default strength is now 100% of these targets; a previously saved user strength is preserved. Whole-card rounding and insufficient matching discoveries can reduce the local proportion. History, editorial protected rows, and new-release rows retain their existing purpose. Genre discovery depends on metadata actually returned by Spotify, and is not guaranteed by every search response.

## Checks completed

- Kotlin 2.2.0 compiled `SongsModel`, `RadioQueuePolicy`, `HomeMixPolicy`, and their focused JUnit tests.
- JUnit 4.13.2: **9 tests passed**. They cover original-seed continuation, ordinary autoplay fallback, resume ordering, the 15-track cap, Spotify-ID deduplication, unavailable recommendations, missing seeds, rotation, and all mix-stage boundaries.
- Tree-sitter parsed all **212 Kotlin files** without syntax errors. This is not Android compilation, type checking, Compose execution, or import resolution.
- Manually inspected changed imports, ViewModel signatures, navigation, download wiring, and shared state references. Radio's `Icons.Default.Download` dependency was replaced with Spotui's existing `ic_download` drawable to avoid relying on an unavailable extended icon import.
- Inspected `AlbumScreen.kt`: the outer `artist` argument is used for loading; collection UI references use album/track artist metadata. No remaining out-of-scope `artist` reference was found by source inspection.
- Workflow YAML structure and exact requested build command checked. Archive integrity checked during packaging.

## Android build result

The first wrapper attempt failed downloading Gradle. Gradle 8.6 was then obtained separately and a second `:app:assembleDebug --no-daemon --max-workers=2` attempt started, but stopped during resolution of Android Gradle plugin `com.android.application:8.4.2`. No Kotlin Android compilation took place. The existing playback buffering, timer, and resume complaints therefore remain unverified; this package must not be described as fixing those symptoms conclusively.

GitHub Actions must provide the full Android compilation and unit-test gate. The supplied workflow uses Java 17, Android setup, builds directly from the ZIP in an isolated directory, runs the app unit tests, and uploads the debug APK only if those steps succeed. An obsolete workflow that patched the app into a separate Radio package was replaced in the ZIP by the matching modified-app workflow.

## Phone upload/build steps

1. Upload `Spotui-Modified-integrated-source.zip` to the repository root: https://github.com/rare621/Spotui/upload/main
2. Replace the contents of `.github/workflows/build-spotui-modified.yml` with the supplied YAML: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Open https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml and select **Run workflow** on `main`.
4. Open the successful run and download **Spotui-Modified-APK** under Artifacts. Extract the APK on the phone.

The ZIP filename in the workflow must match exactly. These files have not been pushed to GitHub by this handoff.

## Required phone checks before calling it finished

- Open an existing album, playlist, and Radio; confirm dark detail screens and original artwork/icon.
- Start Radio from a seed, play a different track, switch collections, and reopen the Radio. Confirm its last track is first and recommendations still derive from its original seed. Repeat with two distinct Radios and beyond eight saved Radios.
- Let a Radio run beyond its displayed queue with the screen off; test rapid skipping while recommendations are pending.
- Download Radio tracks, restart the app without connectivity, and play through existing Downloads. Verify the displayed tracks available offline.
- Long-press each applicable Home item; confirm it disappears and another eligible collection backfills without changing Spotify library content.
- Swipe a saved album, a followed playlist, and an owned playlist. Cancel first, then confirm on disposable test items. Check Spotify separately and confirm playlist contents remain intact.
- Create an empty playlist, add one through four recommended songs, close/reopen, and confirm the cover and membership. Test denied permissions and failed uploads.
- Enable each equalizer preset; test speaker, Bluetooth, wired output if available, pause/resume, track changes, crossfade, and disable. Confirm no residual equalization when off.
- Toggle shuffle on/off from all collection types and the player; verify the green state follows playback and removed queue tracks do not reappear when restoring order.
- Like/unlike from the full player, mini player, song menus, search, artist, album, and liked-song rows; confirm the same account changes in Spotify. Test failed synchronization and its visible message.

Debug APKs use the runner's debug signing key. Version increments alone do not make them upgrade a build signed with another key. Keep a consistent signing key for reliable upgrades; do not uninstall an existing installation without preserving downloads and local history.
