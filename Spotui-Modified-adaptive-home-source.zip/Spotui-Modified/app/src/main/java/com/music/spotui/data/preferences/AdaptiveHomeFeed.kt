package com.music.spotui.data.preferences

import android.content.Context
import com.music.spotui.data.entity.HomeFeedModel
import com.music.spotui.data.entity.HomeItem
import com.music.spotui.data.entity.HomeSection
import java.util.Locale
import kotlin.math.exp

/** Mix Spotify's existing recommendations with new Spotify catalog discoveries.
 *  Keeps Spotify collection IDs and original navigation; never invents playlists.
 *  Recent plays are weighted more heavily and newly discovered cards are introduced
 *  gradually without overwriting the special history or top shortcut sections.
 */
object AdaptiveHomeFeed {
    private fun key(s: String) = s.trim().lowercase(Locale.ROOT)
    private fun id(item: HomeItem): String = when (item) {
        is HomeItem.Playlist -> "playlist:" + item.id
        is HomeItem.Album -> "album:" + key(item.name) + ":" + key(item.artists)
        is HomeItem.Artist -> "artist:" + item.id
        is HomeItem.Radio -> "radio:" + item.seed.id
        is HomeItem.RecentTrack -> "track:" + item.song.id
    }
    fun blend(context: Context, original: HomeFeedModel, discoveries: List<HomeSection>): HomeFeedModel {
        val prefs = HomePersonalization
        val ranked = prefs.rank(context, original)
        if (!prefs.enabled(context) || prefs.strength(context) == 0) return ranked
        val now = System.currentTimeMillis()
        val window = prefs.windowDays(context)
        val plays = getListeningHistory(context).filter {
            it.source != "spotify" && (window <= 0 || now - it.ts <= window.toLong() * 86_400_000L)
        }
        if (plays.size < 3 || discoveries.isEmpty()) return ranked
        val artistWeights = mutableMapOf<String, Double>()
        val albumWeights = mutableMapOf<String, Double>()
        plays.forEach { play ->
            val weight = exp(-((now - play.ts).coerceAtLeast(0L) / 86_400_000.0) / 45.0)
            play.singer.split(",", " & ", " feat. ", " ft. ").map(::key).filter { it.length > 2 }.forEach {
                artistWeights[it] = (artistWeights[it] ?: 0.0) + weight
            }
            key(play.album).takeIf { it.length > 2 }?.let { album ->
                albumWeights[album] = (albumWeights[album] ?: 0.0) + weight
            }
        }
        fun score(item: HomeItem): Double {
            val words = when(item) {
                is HomeItem.Album -> key(item.name + " " + item.artists)
                is HomeItem.Playlist -> key(item.name + " " + item.subtitle)
                else -> key(item.name)
            }
            return artistWeights.entries.sumOf { (name, weight) -> if (words.contains(name)) weight else 0.0 } +
                albumWeights.entries.sumOf { (name, weight) -> if (words.contains(name)) weight * 1.5 else 0.0 }
        }
        val pool = discoveries.flatMap { it.items }.distinctBy(::id)
        val used = ranked.sections.flatMap { it.items }.map(::id).toMutableSet()
        val sections = ranked.sections.map { section ->
            val title = section.title.lowercase(Locale.ROOT)
            // Never alter the shortcut grid, personal mixes, history, artists, or
            // explicitly time-sensitive / editorial sections.
            val eligible = title.isNotBlank() && !listOf(
                "recently played", "made for", "your top mixes", "favorite artists",
                "new releases", "biggest hits", "popular radio", "party",
                "discover playlists", "discover albums"
            ).any(title::contains) && (listOf(
                "more like", "more of what", "recommended", "based on your",
                "soundtrack", "albums featuring", "discover more"
            ).any(title::contains))
            if (!eligible || section.items.size < 2) return@map section
            val wantsAlbum = title.contains("album")
            val wantsPlaylist = title.contains("playlist") || title.contains("mix") || title.contains("station") || title.contains("radio")
            val candidates = pool.filter { candidate ->
                id(candidate) !in used && when {
                    wantsAlbum -> candidate is HomeItem.Album
                    wantsPlaylist -> candidate is HomeItem.Playlist
                    else -> candidate is HomeItem.Album || candidate is HomeItem.Playlist
                }
            }.sortedWith(compareByDescending<HomeItem>(::score).thenBy { id(it) })
            // Keep most Spotify-supplied cards; insert up to 30% discovered cards.
            // At low personalization strength only one new card is introduced.
            val target = if (prefs.strength(context) < 40) 1 else (section.items.size * 0.3).toInt().coerceAtLeast(1)
            val additions = candidates.take(target.coerceAtMost(3))
            if (additions.isEmpty()) return@map section
            additions.forEach { used.add(id(it)) }
            val kept = section.items.take((section.items.size - additions.size).coerceAtLeast(1))
            val combined = (kept + additions).distinctBy(::id)
            section.copy(items = combined.withIndex().sortedWith(
                compareByDescending<IndexedValue<HomeItem>> { score(it.value) }
                    .thenBy { it.index }
            ).map { it.value })
        }
        // Keep unused discoveries available as dedicated sections, too.
        val extras = discoveries.mapNotNull { section ->
            section.copy(items = section.items.filter { id(it) !in used }.take(12))
                .takeIf { it.items.isNotEmpty() }
        }
        return ranked.copy(sections = sections + extras)
    }
}
