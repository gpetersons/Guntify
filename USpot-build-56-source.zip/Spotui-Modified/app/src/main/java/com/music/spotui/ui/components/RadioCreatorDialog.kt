package com.music.spotui.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.music.spotui.data.api.Response
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.ui.theme.*
import com.music.spotui.ui.viewmodel.RadioCreatorViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun RadioCreatorDialog(mix:Boolean,onDismiss:()->Unit,onCreated:(String)->Unit,model:RadioCreatorViewModel=hiltViewModel()) {
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    val keyboard=androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val fieldColors=OutlinedTextFieldDefaults.colors(focusedTextColor=AppText,unfocusedTextColor=AppText,focusedBorderColor=AppPalette,unfocusedBorderColor=AppSecondary,focusedLabelColor=AppSecondary,unfocusedLabelColor=AppSecondary,cursorColor=AppPalette)
    var query by remember{mutableStateOf("")};var name by remember{mutableStateOf("")}
    val chosen=remember{mutableStateListOf<SongsModel>()}
    var saving by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    val results by model.results.collectAsState()
    LaunchedEffect(Unit){model.search("")}
    Dialog(onDismissRequest={if(!saving)onDismiss()},properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Surface(color=AppBackground,shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth().fillMaxHeight(0.9f).padding(12.dp)) {
            Column(Modifier.padding(20.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(if(mix)"USpot Radio Mix" else "USpot Radio",color=AppText,fontSize=23.sp,fontWeight=FontWeight.Bold)
                    TextButton(enabled=!saving,onClick=onDismiss){Text("Close",color=AppSecondary)}
                }
                Text(if(mix)"Choose up to five songs. Their recommendations become one continuous station." else "Choose a song to start a continuous station.",color=AppSecondary)
                if(mix)OutlinedTextField(value=name,onValueChange={name=it.take(80)},label={Text("Mix name (optional)")},colors=fieldColors,modifier=Modifier.fillMaxWidth().padding(top=12.dp),singleLine=true)
                OutlinedTextField(value=query,onValueChange={query=it;model.search(it)},label={Text("Search Spotify songs")},colors=fieldColors,modifier=Modifier.fillMaxWidth().padding(vertical=12.dp),singleLine=true,enabled=!saving)
                Text("${chosen.size} / ${if(mix)5 else 1} selected",color=AppPalette)
                LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    items(chosen.toList(),key={it.spotifyTrackId}) { song ->
                        Text("${song.title}  ×",color=AppText,maxLines=1,
                            modifier=Modifier.widthIn(max=180.dp).background(AppSurface,RoundedCornerShape(10.dp)).clickable(enabled=!saving){chosen.remove(song)}.padding(horizontal=10.dp,vertical=7.dp))
                    }
                }
                LazyColumn(Modifier.weight(1f).padding(top=8.dp)) {
                    when(val state=results) {
                        is Response.Loading -> item{CircularProgressIndicator(Modifier.padding(16.dp),color=AppPalette)}
                        is Response.Error -> item{Text(state.error,color=AppSecondary)}
                        is Response.Success -> {
                            if(query.isNotBlank() && state.data.isEmpty())item{Text("No songs found. Try the artist and song name.",color=AppSecondary)}
                            items(state.data.filter{it.spotifyTrackId.isNotBlank()}.distinctBy{it.spotifyTrackId},key={it.spotifyTrackId}) { song ->
                                val selected=chosen.any{it.spotifyTrackId==song.spotifyTrackId}
                                Row(Modifier.fillMaxWidth().clickable(enabled=!saving,
                                    interactionSource=remember{MutableInteractionSource()},indication=null) {
                                    if(selected)chosen.removeAll{it.spotifyTrackId==song.spotifyTrackId}
                                    else if(mix && chosen.size<5)chosen.add(song)
                                    else if(!mix){chosen.clear();chosen.add(song)}
                                    keyboard?.hide()
                                }.padding(vertical=9.dp)) {
                                    GlideImage(model=song.coverUri,contentDescription=null,modifier=Modifier.size(48.dp))
                                    Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
                                        Text(song.title,color=if(selected)AppPalette else AppText,maxLines=1,fontWeight=FontWeight.SemiBold)
                                        Text(song.singer,color=AppSecondary,maxLines=1,fontSize=12.sp)
                                    }
                                    Text(if(selected)"✓" else "+",color=if(selected)AppPalette else AppSecondary,fontSize=24.sp)
                                }
                            }
                        }
                    }
                }
                if(error.isNotBlank())Text(error,color=AppSecondary)
                Button(enabled=chosen.isNotEmpty()&&!saving,onClick={
                    saving=true;error=""
                    scope.launch {
                        try { val marker=model.create(context,chosen.toList(),name,mix);onCreated(marker.spotifyTrackId) } catch(cancelled:kotlinx.coroutines.CancellationException){throw cancelled} catch(failed:Exception){error="Couldn't save the station. Try again."}
                        finally{saving=false}
                    }
                },modifier=Modifier.fillMaxWidth().padding(top=12.dp),colors=ButtonDefaults.buttonColors(containerColor=AppPalette)) {
                    Text(if(saving)"Creating…" else "Create Radio",color=AppBackground)
                }
            }
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable fun SavedRadiosLibrary(navController:androidx.navigation.NavController,query:String) {
    val context=LocalContext.current
    var revision by remember{mutableStateOf(0)}
    var saved by remember{mutableStateOf(emptyList<SongsModel>())}
    DisposableEffect(context) {
        val prefs=context.getSharedPreferences("spotui_radio_sessions",0)
        val listener=android.content.SharedPreferences.OnSharedPreferenceChangeListener{_,_->revision++}
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose{prefs.unregisterOnSharedPreferenceChangeListener(listener)}
    }
    LaunchedEffect(revision){saved=kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){com.music.spotui.data.preferences.RadioSessions.get(context)}}
    val visible=saved.filter{query.isBlank() || it.title.contains(query,true) || it.singer.contains(query,true)}
    val player:com.music.spotui.ui.viewmodel.PlayerViewModel=hiltViewModel()
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=16.dp,end=16.dp,bottom=140.dp,top=12.dp)) {
        if(visible.isEmpty())item{Text("Your USpot radios appear here. Create one using + on Home.",color=AppSecondary)}
        items(visible,key={it.spotifyTrackId.ifBlank{it.id.toString()}}) { song ->
            val id=song.spotifyTrackId.ifBlank{song.id.toString()}
            val active=player.activeCollection.value?.key=="radio:$id"
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).playbackGlow(active).clickable{
                navController.navigate("radio/"+android.net.Uri.encode(id))
            }.padding(10.dp)) {
                GlideImage(model=song.coverUri,contentDescription=null,modifier=Modifier.size(60.dp))
                Column(Modifier.weight(1f).padding(start=14.dp)) {
                    Text(com.music.spotui.data.preferences.RadioSessions.stationName(song),color=if(active)AppPalette else AppText,fontWeight=FontWeight.SemiBold)
                    Text(if(com.music.spotui.data.preferences.RadioSessions.isMix(id))"USpot Radio Mix · ${song.singer}" else "USpot Radio · ${song.singer}",color=AppSecondary,fontSize=12.sp)
                }
                if(active)PlayingBars(player.currentSongPlayingState.value)
            }
        }
    }
}
