package com.music.spotui.data.recommendation

import com.music.spotui.data.entity.*
import com.music.spotui.data.preferences.HomeHiddenItems
import org.junit.Assert.*
import org.junit.Test

class HomePresentationTest {
    private fun playlist(id: Int) = HomeItem.Playlist("Mix $id", "art", "Playlist", "id$id")
    private fun feed(items: List<HomeItem>) = HomeFeedModel(sections = listOf(HomeSection("", items), HomeSection("Made For listener", items)))
    private fun prepare(feed: HomeFeedModel, local: List<HomeItem> = emptyList(), frequent: List<HomeItem> = emptyList(), hidden: Set<String> = emptySet(), max: Int = 8) =
        HomePresentationPolicy.prepare(feed, emptyList(), local, frequent, hidden, 0.0, "listener", max)

    @Test fun hiddenRotationCardsBackfillFromOlderCollectionsBeforeLimit() {
        val items = (1..12).map(::playlist)
        val ready = prepare(feed(items), items, items.take(2), setOf(HomeHiddenItems.key(items.first())))
        assertEquals((2..9).map(::playlist), ready.topTiles)
        assertFalse(ready.sections.flatMap { it.items }.contains(items.first()))
    }
    @Test fun individualSongsNeverDisplaceRotationCollections() {
        val track = HomeItem.RecentTrack(SongsModel(1,"Song","Album","Artist","art","url"))
        val ready = prepare(feed(listOf(track, playlist(1))), listOf(track))
        assertEquals(listOf(playlist(1)), ready.topTiles)
    }
    @Test fun newUserRetainsSpotifyFallbackAndHasNoLocalActivity() {
        val items = (1..10).map(::playlist)
        val ready = prepare(feed(items))
        assertEquals(items.take(8), ready.topTiles)
        assertFalse(ready.hasLocalActivity)
        assertEquals(items.take(5), ready.sections.first().items)
    }
    @Test fun actualLocalRecentActivityReplacesSpotifyHistoryAndRespectsLimit() {
        val base = feed((1..5).map(::playlist)).copy(sections = listOf(HomeSection("Recently played", listOf(playlist(99)))) + feed((1..5).map(::playlist)).sections)
        val ready = prepare(base, (10..15).map(::playlist), max = 2)
        assertEquals(listOf(playlist(10), playlist(11)), ready.sections.first().items)
        assertEquals("Recently played", ready.sections.first().title)
        assertTrue(ready.hasLocalActivity)
    }
    @Test fun hiddenRecentActivityCannotReappearOrConsumeRecentLimit() {
        val local = (10..15).map(::playlist)
        val ready = prepare(feed((1..5).map(::playlist)), local, hidden = setOf(HomeHiddenItems.key(local.first())), max = 2)
        assertEquals(listOf(playlist(11), playlist(12)), ready.sections.first().items)
    }
    @Test fun duplicateCatalogItemsCannotCreateDuplicateLazyRowKeys() {
        val p = playlist(1)
        val ready = prepare(feed(listOf(p,p)), listOf(p,p))
        ready.sections.forEach { row -> assertEquals(row.items.size, row.items.map(HomeHiddenItems::key).distinct().size) }
    }
    @Test fun localRecommendationsStillReplaceSpotifyAtFullInfluence() {
        val album = HomeItem.Album("Local album","art","Artist","Artist")
        val ready = HomePresentationPolicy.prepare(HomeFeedModel(), listOf(HomeSection(LocalHomePolicy.ALBUMS,listOf(album))), emptyList(), emptyList(), emptySet(), 1.0, "account",8)
        assertEquals("Made For account", ready.sections.single().title)
        assertEquals(listOf(album), ready.sections.single().items)
    }
    @Test fun hiddenDiscoveryDoesNotReappearThroughPersonalization() {
        val p = playlist(1)
        val ready = HomePresentationPolicy.prepare(HomeFeedModel(), listOf(HomeSection(LocalHomePolicy.PLAYLISTS,listOf(p))), emptyList(), emptyList(), setOf(HomeHiddenItems.key(p)),1.0,"account",8)
        assertTrue(ready.sections.isEmpty())
    }
}
