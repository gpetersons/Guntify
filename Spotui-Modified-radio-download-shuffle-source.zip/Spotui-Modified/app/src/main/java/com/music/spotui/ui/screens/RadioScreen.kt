package com.music.spotui.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.bumptech.glide.integration.compose.placeholder
import com.music.spotui.R
import com.music.spotui.data.entity.SongsModel
import com.music.spotui.data.preferences.RadioSessions
import com.music.spotui.ui.theme.AppBackground
import com.music.spotui.ui.viewmodel.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Playlist-style Spotify radio preview. Persist only the original seed, never the queue. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalGlideComposeApi::class, ExperimentalFoundationApi::class)
@Composable
fun RadioScreen(navController: NavController, seedId: String, player: PlayerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val seed = remember(seedId) { RadioSessions.get(context).firstOrNull {
        it.spotifyTrackId == seedId || (it.spotifyTrackId.isBlank() && it.id.toString() == seedId)
    } }
    val lastPlayed = remember(seedId) { RadioSessions.lastTrack(context, seedId) }
    // Resume position is never used as the recommendation seed.
    var tracks by remember(seedId) { mutableStateOf<List<SongsModel>>(emptyList()) }
    var loading by remember(seedId) { mutableStateOf(true) }
    var shuffleEnabled by remember(seedId) { mutableStateOf(false) }
    var showDownloadConfirmation by remember(seedId) { mutableStateOf(false) }
    var menuSong by remember { mutableStateOf<SongsModel?>(null) }
    menuSong?.let { song ->
        com.music.spotui.ui.components.SongOptionsSheet(
            song = song, navController = navController, context = context,
            onDismiss = { menuSong = null }
        )
    }
    if (showDownloadConfirmation) {
        AlertDialog(
            onDismissRequest = { showDownloadConfirmation = false },
            title = { Text("Download radio") },
            text = { Text("Download the ${tracks.size} songs currently shown for offline listening? These songs will use Spotui’s existing download storage.") },
            confirmButton = { TextButton(onClick = {
                com.music.spotui.di.Downloads.downloadAll(tracks, context)
                showDownloadConfirmation = false
            }) { Text("Download") } },
            dismissButton = { TextButton(onClick = { showDownloadConfirmation = false }) { Text("Cancel") } }
        )
    }
    LaunchedEffect(seedId) {
        loading = true
        val suggestions = if (seed?.spotifyTrackId.isNullOrBlank()) emptyList() else
            withContext(Dispatchers.IO) { player.radioRecommendations(seed!!.spotifyTrackId) }
        // Resume with the last played track; fill the remaining slots with fresh,
        // deduplicated suggestions. Rotate results so reopening isn't identical.
        val previous = lastPlayed?.let { listOf(it) }.orEmpty()
        val candidates = suggestions.filter { candidate ->
            candidate.id != seed?.id && previous.none { it.id == candidate.id }
        }.distinctBy { it.id }
        val offset = if (candidates.isEmpty()) 0 else
            (System.currentTimeMillis() / 60000L % candidates.size).toInt()
        tracks = (previous + (candidates.drop(offset) + candidates.take(offset))).distinctBy { it.id }.take(15)
        loading = false
    }
    val background = AppBackground
    Surface(modifier = Modifier.fillMaxSize(), color = background) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                CenterAlignedTopAppBar(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    title = {},
                    navigationIcon = {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back", tint = Color.White,
                            modifier = Modifier.clickable { navController.navigateUp() }
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { insets ->
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = insets.calculateTopPadding(), bottom = 150.dp)
            ) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 440.dp)
                            .background(Brush.verticalGradient(listOf(Color(0xFF242631), background))),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Spacer(Modifier.height(45.dp))
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            GlideImage(
                                model = seed?.coverUri,
                                contentDescription = "Radio artwork",
                                failure = placeholder(R.drawable.placeholder),
                                modifier = Modifier.size(230.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(
                            text = "${seed?.title ?: "Song"} Radio",
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 20.dp)
                        )
                        Text(
                            text = "Radio • Based on ${seed?.title ?: "song"} · ${seed?.singer.orEmpty()}",
                            color = Color.LightGray, fontSize = 12.sp,
                            modifier = Modifier.padding(start = 20.dp, top = 9.dp, end = 20.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 20.dp),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (tracks.isNotEmpty()) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download radio songs",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp).clickable { showDownloadConfirmation = true }
                                )
                                Spacer(Modifier.width(20.dp))
                                Icon(
                                    painter = painterResource(R.drawable.ic_player_shuffle),
                                    contentDescription = "Shuffle radio", tint = if (shuffleEnabled) Color(0xFF1DB954) else Color.White,
                                    modifier = Modifier.size(24.dp).clickable {
                                        shuffleEnabled = !shuffleEnabled
                                        val ordered = if (shuffleEnabled) tracks.shuffled() else tracks
                                        player.resumeRadio(seed ?: return@clickable, ordered, context)
                                    }
                                )
                                Spacer(Modifier.width(20.dp))
                            }
                            Box(
                                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(100.dp))
                                    .background(Color.White).clickable {
                                        seed?.let {
                                            if (tracks.isNotEmpty()) player.resumeRadio(it, tracks, context)
                                            else player.startRadioFromSong(it, context)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.play_svgrepo_com),
                                    contentDescription = "Play radio", tint = Color.Black,
                                    modifier = Modifier.size(25.dp)
                                )
                            }
                        }
                    }
                }
                item {
                    Text(
                        "Up next · ${tracks.size} songs", color = Color.White, fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 20.dp, top = 10.dp, bottom = 12.dp)
                    )
                    if (loading) CircularProgressIndicator(Modifier.padding(20.dp))
                    if (!loading && tracks.isEmpty()) Text(
                        "Recommendations aren't available right now. Try reopening this radio.",
                        color = Color.Gray, modifier = Modifier.padding(20.dp)
                    )
                }
                itemsIndexed(tracks) { index, song ->
                    com.music.spotui.ui.components.SwipeToQueue(song) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)
                                .combinedClickable(
                                    onClick = {
                                        seed?.let { player.resumeRadio(it, tracks.drop(index) + tracks.take(index), context) }
                                    },
                                    onLongClick = { menuSong = song }
                                ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlideImage(
                                model = song.coverUri,
                                contentDescription = "", failure = placeholder(R.drawable.placeholder),
                                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(4.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                                Text(song.title, color = Color.White, fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium, maxLines = 1)
                                Text(song.singer, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                            }
                            Text(
                                "⋮", color = Color.LightGray, fontSize = 22.sp,
                                modifier = Modifier.clickable { menuSong = song }.padding(8.dp)
                            )
                        }
                    }
                }
                item {
                    Text(
                        "Radio will continue as you listen.", color = Color.Gray,
                        fontSize = 13.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 24.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }
}
