# USpot 1.1 — backup/import and build corrections

Display version remains 1.1; internal Android versionCode advances to 23. Application ID, icon, data directories, and the permanent signing-key setup are unchanged.

## Uploaded build log

The provided Actions run successfully passed the signing-key restore step. It then failed at app:compileDebugKotlin because HomeScreen.kt did not import mutableStateOf. The missing import is corrected.

The log also contained repeated D8 warnings about Kotlin metadata compatibility. This source updates Android Gradle Plugin from 8.4.2 to 8.10.1 and the Gradle wrapper from 8.6 to 8.11.1, retaining Kotlin 2.2.0. The matching workflow explicitly installs Build Tools 35.0.0 and the Android 34 platform. Official compatibility references:
https://developer.android.com/build/kotlin-support
https://developer.android.com/build/releases/agp-8-10-0-release-notes

## New Settings → Data & backup

- Export backup opens Android's Save file picker and writes a USpot backup ZIP outside the app, wherever the user chooses.
- Import backup opens Android's file picker, asks before replacing backed-up local data, pauses playback, and restores the selected archive.
- The backup includes local listening history, likes, saved library/cache data, Home personalization/history/removals, Radio seeds and resume progress, queue/playback position, EQ/appearance/settings, alternative stream choices, and playlist cover files.
- Include downloaded audio is enabled by default and can be disabled for a smaller archive. Download index entries are restored only when their referenced audio files actually exist.
- External local-music file references are retained, but Android file/folder permissions must be granted again after reinstalling or switching devices. The external audio itself is not copied into this backup.
- Passwords, login cookies, access/session tokens, Soulseek usernames, Spotify/SpotiFLAC authentication stores, and private signing keys are excluded. Existing login credentials in the destination installation are preserved. Restore does not submit changes to Spotify.
- Archives use a versioned manifest, explicit file list, byte lengths, and SHA-256 checksums. They are extracted into staging first with path, metadata-size, entry-count, and available-space checks. Validation finishes before live data is replaced. Ordinary restore errors attempt to roll back changed preferences and files.
- Import reloads runtime download/EQ/appearance/playback state and refreshes Settings/Home. Playback stays paused after restore.
- Current downloads must finish before export, preventing active download files from being backed up mid-write.

This feature cannot recover private data from the currently installed old-signed app that has no export button. It protects future installations once this version is installed and a backup is successfully exported. Do not uninstall the old app under the assumption that this new code has already backed it up.

Keep backups private: they contain personal listening history and settings, although account credentials are excluded. Keep the ZIP outside the app so uninstalling does not remove it. Export a backup before restoring another archive if you need to preserve the current local data.

## Validation

- 34 JVM tests passed: all previous policy tests plus backup audio/metadata round-trip, hashes, unsafe-path rejection, extraction quota, malformed archive rejection, and authentication exclusions.
- Four additional codec tests passed against production backup code, covering exact integer/long values, Boolean/Float/String settings, string sets, and rejected unknown types. Total: 38 passing tests.
- All 232 Kotlin source files passed syntax parsing.
- The production backup backend compiled in isolation against Android API classes and org.json; this is not a full Android app build or device test.
- Full Android assembleDebug was attempted using the updated wrapper, but the local environment could not reach the Gradle distribution URL. No new APK was produced here.
- SAF file-picker behavior, permissions, rollback on Android storage failures, runtime refresh, UI, authenticated Spotify features, and install/update behavior still require a successful Actions build and device testing. No claim is made that backup/restore has passed an Android device test.
- Original icon assets remain byte-identical. The complete source ZIP passed integrity checks and includes all preceding USpot modifications.

## Upload/build from your phone

1. Upload USpot-1.1-backup-source.zip unchanged to:
https://github.com/rare621/Spotui/upload/main
2. Replace the existing workflow contents with build-uspot-backup.yml:
https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
3. Keep the EXISTING USPOT_SIGNING_KEYSTORE_BASE64 secret and permanent keystore. Do not generate another key.
4. Run:
https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
5. After both build and tests succeed, download USpot-1.1-APK from Artifacts.

## Phone verification

Export to Downloads with audio, then confirm that the ZIP exists and has a sensible size. Import into a test/fresh installation and compare history, likes, Radio sessions, settings/EQ, covers, and downloaded playback. Check exports without audio, canceled pickers, an unrelated ZIP, corrupted files, insufficient storage, and restoring while music had been playing. After establishing the permanent-key installation, future APKs must install as updates without uninstalling; verify data is still present after one such update.


# USpot 1.1 — build 43

Complete cumulative source based on build 42. All 352 previous source files are retained. Added Home snapshot storage and its unit tests; existing playback, Smart Downloads, Stats, queue Undo, Radio tuning, Smart Shuffle, personalization, Library, backup, equalizer, theme and licensing changes are preserved.

Home startup: the last successful Spotify base feed and personalized discovery shelves are saved locally. The ViewModel restores discovery shelves before the first Home render; the base feed is emitted from storage before network requests. The signed-in account's section titles, item ordering, Spotify IDs and playable Radio seeds survive restart. Refreshes happen in the background; an empty failed shelf retains the previous successful shelf. Personalization settings and listening window remain respected. New users retain Spotify fallbacks. One successful load after installing this build is needed to populate the new cache. Existing artwork caching is unchanged; cold image downloads can still take time.

Account changes/logouts clear the snapshots, and the codec checks a one-way session fingerprint and history-window scope. No credentials or listening history are added to network requests. Cache data is expendable and is not added to exported backups; the user's actual listening history and settings remain in the existing backup system. Package ID and signing configuration remain unchanged; versionCode is 43, display version 1.1. Keep the existing signing key and install as an update.

Player: Smart Shuffle diamond is outside the shuffle glyph, positioned as a separate upper-right badge within a 48dp transparent touch target; accessibility descriptions identify off/on/Smart modes.

Radio tuning: Stay close, Balanced and Explore more have no gray ripple/press highlight. Selection remains green with a transparent background.

Validation: seven new production-code JSON/policy tests passed (all Home item types, ordering/title/ID preservation, account/window rejection, malformed/future format, retaining good shelves and successful replacements). Four storage-adapter tests passed (persisted read, account isolation, empty-result protection and logout clearing). Whole-project Kotlin syntax checks and Android resource compilation also passed; the updated discovery method compiled against the actual Spotify models. These are JVM/source checks, not Android phone tests. Full Android compilation was attempted but stopped before configuration because the Gradle wrapper could not reach services.gradle.org (Network is unreachable). UI appearance, actual cold launch, Bluetooth/Android Auto and authenticated Spotify account operations still require APK/device testing. Earlier build-42 focused test results remain documented separately and are not a substitute for this build's APK test.

Upload USpot-build-43-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-43.yml using https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow compiles/tests the Android project and bundles APK, exact source ZIP and license notices. This build has not been uploaded or run on GitHub by the assistant; connector writes were previously rejected with HTTP 403.


# USpot 1.1 — build 44

Smart Downloads now defaults to disabled. Neither launching nor updating the app enables it. The existing explicit Settings choice is preserved, including users who deliberately enabled the feature. Existing downloaded files are not deleted. The default target remains 20 songs if the user enables it.

All build-43 source and features are retained. Package ID and signing configuration are unchanged; internal versionCode is 44. Install as an update using the existing signing key.

Validation: inspected the production preference getter and confirmed its absent-value default is false. No new Android compilation or device test was performed for this one-line behavior change. Build-43 validation results and limitations still apply. The supplied workflow compiles and tests the Android project on GitHub.

Upload USpot-build-44-source.zip unchanged to the repository root. Replace .github/workflows/build-spotui-modified.yml with build-uspot-44.yml and run the workflow. These files have not been uploaded to GitHub by the assistant.


# USpot 1.1 — build 45

Stats redesign: same visual language as Following, with a theme-aware green gradient hero, four-cover collage, top track, Play/Pause and regular/Smart Shuffle controls. Week/Month/All-time filters have transparent press feedback. Compact plays, recorded time and distinct artist cards; a last-seven-calendar-days activity chart; ranked artwork song rows with play counts; horizontal top-artist cards. Local listening data loads and aggregates off the main thread. Bottom padding uses the actual mini-player/navigation inset.

Playback: song rows call the existing PlayerViewModel queue/state operations and SongPlayer.playSong. The selected track starts at its queue index, with up to ten displayed ranked songs available. Play/Pause resumes the active Stats source; Shuffle uses the same player state and source-scoped indicator as collections. Current tracks have the existing glow/animated playing bars. Each song has a correctly scoped three-dot SongOptionsSheet. Artist cards open the existing artist route. Artist images are artwork from listened tracks, not claimed Spotify profile portraits. The source is named Your top songs • week/month/all time; existing non-Radio loop behavior applies.

Stats accuracy: actual play counts, not Home recommendation scores. Only qualified local listening (>10 seconds, not Spotify-imported or future records) counts. Duplicate Spotify IDs group as one song; local songs group by local ID. Artist names merge case variants and count collaborators once per visit. Calendar activity uses the device time zone. Recorded time remains approximate for legacy history, as explained in the UI; retained history may not cover all historical listening.

Cumulative: includes all build-44 files and prior work, including remembered personalized Home, separate full-player Smart Shuffle diamond, transparent Radio tuning and Smart Downloads disabled by default. Saved explicit settings and existing downloaded files remain untouched. Same application ID, display version 1.1 and signing configuration; internal versionCode 45. Install using the same signing key as an update.

Validation: nine new production stats policy tests passed (qualified plays, frequency ranking, Spotify/local grouping, date ranges, collaborators, device calendar, empty state and artwork fallback). The production StatsContent and stats policy compiled with the real Compose 1.6.8 / Material3 1.2.1 / Glide Compose APIs and Compose compiler, using temporary adapters for navigation, injection, player and storage. This is an isolated compile, not a complete APK build or device playback test. Whole-project Kotlin syntax checks and Android resource compilation passed. A complete Gradle build was attempted but failed before configuration while downloading Gradle 8.11.1: Network is unreachable. Audio output, navigation on-device and rendered appearance still require testing the APK. No GitHub upload or run was performed by the assistant.

Build: upload USpot-build-45-source.zip unchanged to https://github.com/rare621/Spotui/upload/main . Replace .github/workflows/build-spotui-modified.yml with build-uspot-45.yml at https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml . Run https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml . The workflow runs assembleDebug and unit tests, and packages matching source and GPL notices alongside the APK.


# USpot 1.1 — build 46

This is the complete cumulative update: playable Stats redesign plus Recommended playlists and the bug review. All build-45 files are retained; only one new test file is added. Same package ID, original update signing configuration and display version 1.1; internal versionCode 46.

Stats: Following-style green hero/collage, Week/Month/All-time filters, listening totals, seven-day activity, artwork song rankings and horizontal artist cards. Song taps invoke PlayerViewModel queue/state operations and SongPlayer.playSong; the chosen song starts at the correct queue index. Play/Pause, regular/Smart Shuffle, source-scoped glow/animated bars, per-song three-dot menus and existing artist navigation are wired. Artist imagery uses artwork from listened tracks, not claimed artist portraits. Bottom padding follows the mini-player/navigation inset. Actual frequency ranks songs, not recommendation scores; only qualified local plays count. Recorded time for older history remains incomplete. Incomplete newer history metadata now falls back to an available playback URL from an earlier visit to the same song.

Recommended playlists: replaces Recommended Stations/Recommended radios. Only HomeItem.Playlist objects with nonblank Spotify IDs are admitted; Radio seeds and albums cannot masquerade as playlists. Catalog search uses the most influential local artists derived from qualified listening over the selected window, with recency/frequency weighting and extra emphasis on the last week. Candidate playlist tracks are sampled against those artists and Spotify-related artist IDs using the existing Spotify integration. Links open the existing Spotify playlist screen. This is not a claim to use Spotify's proprietary recommendations algorithm or to list only Spotify-owned editorial playlists. Some legitimate playlists may be unavailable through this account's catalog responses.

New users: 0–2 qualified local plays retain 100% original Spotify content; local influence then rises through 20/40/60/80/100% maturity bands, scaled by the user's target slider. Spotify backfills when relevant local discoveries are insufficient. Generic Made For fallback uses the current signed-in account name, while existing Spotify personalized titles are retained. Available Spotify albums and catalog playlists populate fallback shelves; no fake local listening is synthesized. Stats stays empty until there are actual USpot listens. Local listening logs are not uploaded to Spotify.

Cache and review fixes: preserve the last good Home/discovery snapshots and refresh in the background. Older generated Radio cache rows are ignored by the new playlist shelf; its first catalog discovery must load once, then is cached for later starts. Empty discovery responses retain successful shelves. Hidden candidates are filtered before limiting the displayed cards, allowing backfill; collections are deduplicated across the three main shelves. An in-flight discovery is rejected if its settings/window or account changed. Late responses cannot tag/overwrite another account's snapshot. Spotify mutation retries after a confirmed HTTP 401 token refresh now have the same 20-second timeout as the original attempt; unconfirmed timed-out writes are not blindly retried. Local Stats/Following queues no longer become dead Spotify playlist shortcuts in Home history; previously stored dead mix shortcuts are hidden without deleting other history. Their actual song listens still contribute to Stats and personalization. This does not prove live Spotify create/remove/like operations work for the account.

Smart Downloads remains disabled by default; explicit saved choices and existing files are preserved. Prior Radio queue/history/resume, stream preparation, theme, backup/export, equalizer, navigation and GPL notices are retained. No browser/PC version is introduced.

Validation: 42 production policy/JSON tests passed (Home/Spotify fallback/transition, playlist-only shelf and IDs, deduplication, signed-in fallback naming, Stats and cache format); 15 actual queue/preferences/history/download-coordinator tests passed using platform adapters; nine cache/account-change/history-shortcut adapter tests passed; six Spotify-mutation retry/timeout tests passed using the actual mutation code, real Spotify exception types and a controlled token adapter. Total: 72 focused tests. Isolated StatsContent compilation passed with the real Compose/Material3/Glide APIs and Compose compiler, with adapters for navigation/injection/player/storage. Discovery code compiled against real Spotify model types. These are not Android device or live Spotify account tests. Whole-project Kotlin syntax checks and Android resource compilation passed. Full local APK build remains blocked at downloading Gradle 8.11.1 (Network is unreachable), before Android configuration; no APK/device appearance or audio validation is claimed.

Install/build: use USpot-build-46-source.zip unchanged at the repository root. Replace .github/workflows/build-spotui-modified.yml with build-uspot-46.yml. Run the existing GitHub Actions workflow, which compiles/tests Android and bundles APK, matching source and license notices. Preserve the existing signing key and install as an update. No source upload or GitHub run was performed by the assistant.

Upload: https://github.com/rare621/Spotui/upload/main
Workflow editor: https://github.com/rare621/Spotui/edit/main/.github/workflows/build-spotui-modified.yml
Build: https://github.com/rare621/Spotui/actions/workflows/build-spotui-modified.yml
